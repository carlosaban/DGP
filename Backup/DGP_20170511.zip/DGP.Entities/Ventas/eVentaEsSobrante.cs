using System;
using System.Text;

namespace DGP.Entities.Ventas {

    public enum eVentaEsSobrante {
        Si = 1
        ,No = 0
    }
}