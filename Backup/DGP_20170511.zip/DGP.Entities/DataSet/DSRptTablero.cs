﻿namespace DGP.Entities.DataSet {
    
    
    public partial class DSRptTablero {
        partial class TABLERODataTable
        {
        }
    }
}
