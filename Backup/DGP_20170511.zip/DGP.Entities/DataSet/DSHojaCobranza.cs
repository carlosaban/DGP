﻿namespace DGP.Entities.DataSet {


    partial class DSHojaCobranza
    {
    }
}
