﻿namespace DGP.Entities.DataSet {


    partial class DSRptClientes
    {
        partial class DGP_Rpt_Estado_CuentaClienteDataTable
        {
        }
    }
}
