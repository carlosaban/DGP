using System;
using System.Text;

namespace DGP.Entities {

    public enum eAccion {
        Agregar = 0
        ,Modificar = 1
        ,Eliminar = 2
        ,BaseDatos = 3
    }

}