﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DGP.BusinessLogic.Seguridad;
using DGP.Entities.Seguridad;



namespace DGP.Presentation.Seguridad
{
    public partial class frmMantenimientoUsuario : Form
    {
        public frmMantenimientoUsuario()
        {
            InitializeComponent();
        }

        private void frmMantenimientoUsuario_Load(object sender, EventArgs e)
        {
            cargarPersonal();
        }

        private void dataGridView1_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (e.ColumnIndex >= 0)
            {
                if (dataGridView1.Columns[e.ColumnIndex].Name == "claveDataGridViewTextBoxColumn" && e.Value != null)
                {
                    dataGridView1.Rows[e.RowIndex].Tag = e.Value;
                    e.Value = new String('\u2022', e.Value.ToString().Length);
                }
            }  
        }

        private void dataGridView1_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
                if (dataGridView1.CurrentRow.Tag != null) e.Control.Text = dataGridView1.CurrentRow.Tag.ToString();

        }

        private void btnAgregarPersonal_Click(object sender, EventArgs e)
        {
            try
            {
                string pmensaje= string.Empty;
                if (!validar( ref pmensaje))
                {
                    MessageBox.Show(this, pmensaje, "Error", MessageBoxButtons.OK);
                    return;
                
                }
                
                BEPersonal oBEPersonal = new BEPersonal();
                oBEPersonal.Clave = this.txtPassword.Text;
                oBEPersonal.correo = this.txtCorreo.Text;
                oBEPersonal.Direccion = this.txtDireccion.Text;
                oBEPersonal.DNI = this.txtDNI.Text;
                oBEPersonal.Estado = 1;
                oBEPersonal.idPerfil = (int)this.cmbPerfil.SelectedValue;
                oBEPersonal.Nombre = txtNombre.Text;
                BLPersonal oBLPersonal = new BLPersonal();
                bool bOk = oBLPersonal.InsertarPersonal(ref pmensaje, oBEPersonal);

                if (!bOk)
                {
                    MessageBox.Show(this, pmensaje, "Error", MessageBoxButtons.OK);
                    return;
                }
                this.cargarPersonal();


            }
            catch (Exception ex)
            {
                
                throw ex;
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        private bool validar(ref string pmensaje)
        {
            return true;
        
        }
        private void  cargarPersonal()
        {
            DGP.BusinessLogic.Seguridad.BLPersonal oBLPersonal = new BLPersonal();
            this.bdsPersonal.DataSource = oBLPersonal.ListarPersonal(new DGP.Entities.Seguridad.BEPersonal());
        
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            var senderGrid = (DataGridView)sender;

            if (senderGrid.Columns[e.ColumnIndex] is DataGridViewButtonColumn &&
                e.RowIndex >= 0)
            {
                //TODO - Button Clicked - Execute Code Here

                string pmensaje = string.Empty;


                DialogResult dialogResult = MessageBox.Show(this, "Desea Actualizar?", "DGP", MessageBoxButtons.YesNo);
                if (dialogResult == DialogResult.Yes)
                {
                    BEPersonal oBEPersonal = new BEPersonal();

                    oBEPersonal.Clave = senderGrid["Clave", e.RowIndex].Value.ToString();
                    oBEPersonal.correo = senderGrid["Correo", e.RowIndex].Value.ToString();
                    oBEPersonal.Direccion = senderGrid["Direccion", e.RowIndex].Value.ToString();
                    oBEPersonal.DNI = senderGrid["DNI", e.RowIndex].Value.ToString();
                   // oBEPersonal.Estado = (int)(senderGrid["Estado", e.RowIndex].Value.ToString()) ;
                    //oBEPersonal.idPerfil = (int)(senderGrid["Perfil", e.RowIndex].Value.ToString()) ;
                    oBEPersonal.Login = senderGrid["Login", e.RowIndex].Value.ToString();
                    oBEPersonal.Nombre = senderGrid["Nombre", e.RowIndex].Value.ToString();
                    BLPersonal oBLPersonal = new BLPersonal();
                    bool bOk = oBLPersonal.ActualizarPersonal(ref pmensaje, oBEPersonal);
                    
                    if (!bOk)
                    {
                        MessageBox.Show(this, pmensaje, "Error", MessageBoxButtons.OK);
                        return;
                    }
                    this.cargarPersonal();

                }

            }
        }

    }
}
