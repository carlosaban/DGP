﻿namespace DGP.Presentation.Ventas
{
    partial class frmDevoluciones
    {
        /// <summary>
        /// Variable del diseñador requerida.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén utilizando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben eliminar; false en caso contrario, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido del método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle27 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle34 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle28 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle29 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle30 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle31 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle32 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle33 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle35 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle36 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle37 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle38 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle39 = new System.Windows.Forms.DataGridViewCellStyle();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.dgrvDevolucion = new System.Windows.Forms.DataGridView();
            this.Column00 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column01 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column02 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column03 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column04 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column05 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column06 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column07 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column08 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column09 = new System.Windows.Forms.DataGridViewButtonColumn();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.lblPrecio = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label6 = new System.Windows.Forms.Label();
            this.lblTotalNeto = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblTotalTara = new System.Windows.Forms.Label();
            this.lblTotalBruto = new System.Windows.Forms.Label();
            this.lblProducto = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.cbVenta = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.cbCliente = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnAceptarDevolucion = new System.Windows.Forms.Button();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgrvDevolucion)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.dgrvDevolucion);
            this.groupBox1.Controls.Add(this.groupBox2);
            this.groupBox1.Controls.Add(this.btnAceptarDevolucion);
            this.groupBox1.Location = new System.Drawing.Point(5, 3);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(966, 307);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Devolución";
            // 
            // dgrvDevolucion
            // 
            this.dgrvDevolucion.AllowUserToAddRows = false;
            this.dgrvDevolucion.AllowUserToDeleteRows = false;
            this.dgrvDevolucion.AllowUserToResizeColumns = false;
            this.dgrvDevolucion.AllowUserToResizeRows = false;
            dataGridViewCellStyle27.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle27.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle27.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            dataGridViewCellStyle27.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle27.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle27.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle27.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgrvDevolucion.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle27;
            this.dgrvDevolucion.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgrvDevolucion.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column00,
            this.Column01,
            this.Column02,
            this.Column03,
            this.Column04,
            this.Column05,
            this.Column06,
            this.Column07,
            this.Column08,
            this.Column09});
            this.dgrvDevolucion.Location = new System.Drawing.Point(254, 22);
            this.dgrvDevolucion.Margin = new System.Windows.Forms.Padding(5);
            this.dgrvDevolucion.MultiSelect = false;
            this.dgrvDevolucion.Name = "dgrvDevolucion";
            this.dgrvDevolucion.RowHeadersWidth = 25;
            this.dgrvDevolucion.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dataGridViewCellStyle34.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgrvDevolucion.RowsDefaultCellStyle = dataGridViewCellStyle34;
            this.dgrvDevolucion.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgrvDevolucion.Size = new System.Drawing.Size(700, 236);
            this.dgrvDevolucion.TabIndex = 12;
            this.dgrvDevolucion.CellBeginEdit += new System.Windows.Forms.DataGridViewCellCancelEventHandler(this.dgrvDevolucion_CellBeginEdit);
            this.dgrvDevolucion.RowsAdded += new System.Windows.Forms.DataGridViewRowsAddedEventHandler(this.dgrvDevolucion_RowsAdded);
            this.dgrvDevolucion.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgrvDevolucion_CellEndEdit);
            this.dgrvDevolucion.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgrvDevolucion_CellMouseClick);
            this.dgrvDevolucion.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgrvDevolucion_CellContentClick);
            // 
            // Column00
            // 
            this.Column00.HeaderText = "FlagJava";
            this.Column00.Name = "Column00";
            this.Column00.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Column00.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Column00.Visible = false;
            this.Column00.Width = 65;
            // 
            // Column01
            // 
            this.Column01.HeaderText = "TaraCalculado";
            this.Column01.MaxInputLength = 11;
            this.Column01.Name = "Column01";
            this.Column01.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Column01.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Column01.Visible = false;
            this.Column01.Width = 130;
            // 
            // Column02
            // 
            this.Column02.HeaderText = "FlagPesoTara";
            this.Column02.Name = "Column02";
            this.Column02.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Column02.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Column02.Visible = false;
            this.Column02.Width = 95;
            // 
            // Column03
            // 
            this.Column03.DataPropertyName = "CantidadJavas";
            dataGridViewCellStyle28.Format = "N0";
            dataGridViewCellStyle28.NullValue = null;
            this.Column03.DefaultCellStyle = dataGridViewCellStyle28;
            this.Column03.HeaderText = "Cantidad Javas";
            this.Column03.MaxInputLength = 4;
            this.Column03.Name = "Column03";
            this.Column03.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Column03.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Column03.Width = 70;
            // 
            // Column04
            // 
            this.Column04.DataPropertyName = "PesoJava";
            dataGridViewCellStyle29.Format = "N2";
            dataGridViewCellStyle29.NullValue = null;
            this.Column04.DefaultCellStyle = dataGridViewCellStyle29;
            this.Column04.HeaderText = "Peso Javas";
            this.Column04.MaxInputLength = 11;
            this.Column04.Name = "Column04";
            this.Column04.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Column04.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Column04.Width = 70;
            // 
            // Column05
            // 
            dataGridViewCellStyle30.Format = "N2";
            dataGridViewCellStyle30.NullValue = null;
            this.Column05.DefaultCellStyle = dataGridViewCellStyle30;
            this.Column05.HeaderText = "Peso Bruto";
            this.Column05.MaxInputLength = 11;
            this.Column05.Name = "Column05";
            this.Column05.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Column05.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Column05.Width = 70;
            // 
            // Column06
            // 
            dataGridViewCellStyle31.Format = "N2";
            dataGridViewCellStyle31.NullValue = null;
            this.Column06.DefaultCellStyle = dataGridViewCellStyle31;
            this.Column06.HeaderText = "Peso Tara";
            this.Column06.MaxInputLength = 11;
            this.Column06.Name = "Column06";
            this.Column06.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Column06.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Column06.Width = 70;
            // 
            // Column07
            // 
            dataGridViewCellStyle32.Format = "N2";
            dataGridViewCellStyle32.NullValue = null;
            this.Column07.DefaultCellStyle = dataGridViewCellStyle32;
            this.Column07.HeaderText = "Peso Neto";
            this.Column07.MaxInputLength = 11;
            this.Column07.Name = "Column07";
            this.Column07.ReadOnly = true;
            this.Column07.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Column07.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Column07.Width = 70;
            // 
            // Column08
            // 
            this.Column08.DataPropertyName = "Observacion";
            this.Column08.HeaderText = "Observación";
            this.Column08.MaxInputLength = 200;
            this.Column08.Name = "Column08";
            this.Column08.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Column08.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Column08.Width = 240;
            // 
            // Column09
            // 
            dataGridViewCellStyle33.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle33.BackColor = System.Drawing.Color.WhiteSmoke;
            dataGridViewCellStyle33.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle33.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle33.SelectionBackColor = System.Drawing.Color.Gray;
            this.Column09.DefaultCellStyle = dataGridViewCellStyle33;
            this.Column09.HeaderText = "Acción";
            this.Column09.Name = "Column09";
            this.Column09.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Column09.Text = "Eliminar";
            this.Column09.UseColumnTextForButtonValue = true;
            this.Column09.Width = 70;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.lblPrecio);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.groupBox3);
            this.groupBox2.Controls.Add(this.lblProducto);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.cbVenta);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.cbCliente);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Location = new System.Drawing.Point(8, 15);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox2.Size = new System.Drawing.Size(239, 280);
            this.groupBox2.TabIndex = 10;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Venta";
            // 
            // lblPrecio
            // 
            this.lblPrecio.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblPrecio.Location = new System.Drawing.Point(68, 110);
            this.lblPrecio.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPrecio.Name = "lblPrecio";
            this.lblPrecio.Size = new System.Drawing.Size(162, 25);
            this.lblPrecio.TabIndex = 17;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.label5.Location = new System.Drawing.Point(4, 111);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(47, 16);
            this.label5.TabIndex = 16;
            this.label5.Text = "Precio";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.lblTotalNeto);
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Controls.Add(this.lblTotalTara);
            this.groupBox3.Controls.Add(this.lblTotalBruto);
            this.groupBox3.Location = new System.Drawing.Point(7, 138);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(223, 130);
            this.groupBox3.TabIndex = 14;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Detalle Venta";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(7, 60);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(77, 16);
            this.label6.TabIndex = 12;
            this.label6.Text = "Total Tara :";
            // 
            // lblTotalNeto
            // 
            this.lblTotalNeto.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblTotalNeto.Location = new System.Drawing.Point(104, 93);
            this.lblTotalNeto.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTotalNeto.Name = "lblTotalNeto";
            this.lblTotalNeto.Size = new System.Drawing.Size(107, 25);
            this.lblTotalNeto.TabIndex = 6;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(7, 94);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(77, 16);
            this.label4.TabIndex = 5;
            this.label4.Text = "Total Neto :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(7, 26);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(79, 16);
            this.label3.TabIndex = 4;
            this.label3.Text = "Total Bruto :";
            // 
            // lblTotalTara
            // 
            this.lblTotalTara.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblTotalTara.Location = new System.Drawing.Point(104, 25);
            this.lblTotalTara.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTotalTara.Name = "lblTotalTara";
            this.lblTotalTara.Size = new System.Drawing.Size(107, 25);
            this.lblTotalTara.TabIndex = 13;
            // 
            // lblTotalBruto
            // 
            this.lblTotalBruto.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblTotalBruto.Location = new System.Drawing.Point(104, 59);
            this.lblTotalBruto.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTotalBruto.Name = "lblTotalBruto";
            this.lblTotalBruto.Size = new System.Drawing.Size(107, 25);
            this.lblTotalBruto.TabIndex = 11;
            // 
            // lblProducto
            // 
            this.lblProducto.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblProducto.Location = new System.Drawing.Point(68, 77);
            this.lblProducto.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblProducto.Name = "lblProducto";
            this.lblProducto.Size = new System.Drawing.Size(162, 25);
            this.lblProducto.TabIndex = 15;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.label7.Location = new System.Drawing.Point(4, 78);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(62, 16);
            this.label7.TabIndex = 14;
            this.label7.Text = "Producto";
            // 
            // cbVenta
            // 
            this.cbVenta.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbVenta.FormattingEnabled = true;
            this.cbVenta.Location = new System.Drawing.Point(55, 47);
            this.cbVenta.Margin = new System.Windows.Forms.Padding(4);
            this.cbVenta.Name = "cbVenta";
            this.cbVenta.Size = new System.Drawing.Size(175, 24);
            this.cbVenta.TabIndex = 3;
            this.cbVenta.SelectedIndexChanged += new System.EventHandler(this.cbVenta_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(4, 50);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(43, 16);
            this.label2.TabIndex = 2;
            this.label2.Text = "Venta";
            // 
            // cbCliente
            // 
            this.cbCliente.FormattingEnabled = true;
            this.cbCliente.Location = new System.Drawing.Point(55, 15);
            this.cbCliente.Margin = new System.Windows.Forms.Padding(4);
            this.cbCliente.Name = "cbCliente";
            this.cbCliente.Size = new System.Drawing.Size(175, 24);
            this.cbCliente.TabIndex = 1;
            this.cbCliente.Leave += new System.EventHandler(this.cbCliente_Leave);
            this.cbCliente.KeyUp += new System.Windows.Forms.KeyEventHandler(this.cbCliente_KeyUp);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(4, 19);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Cliente";
            // 
            // btnAceptarDevolucion
            // 
            this.btnAceptarDevolucion.Location = new System.Drawing.Point(835, 267);
            this.btnAceptarDevolucion.Margin = new System.Windows.Forms.Padding(4);
            this.btnAceptarDevolucion.Name = "btnAceptarDevolucion";
            this.btnAceptarDevolucion.Size = new System.Drawing.Size(119, 28);
            this.btnAceptarDevolucion.TabIndex = 9;
            this.btnAceptarDevolucion.Text = "Aceptar";
            this.btnAceptarDevolucion.UseVisualStyleBackColor = true;
            this.btnAceptarDevolucion.Click += new System.EventHandler(this.btnAceptarDevolucion_Click);
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.HeaderText = "FlagJava";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn1.Visible = false;
            this.dataGridViewTextBoxColumn1.Width = 65;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.HeaderText = "TaraCalculado";
            this.dataGridViewTextBoxColumn2.MaxInputLength = 11;
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn2.Visible = false;
            this.dataGridViewTextBoxColumn2.Width = 130;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.HeaderText = "FlagPesoTara";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn3.Visible = false;
            this.dataGridViewTextBoxColumn3.Width = 95;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "CantidadJavas";
            dataGridViewCellStyle35.Format = "N0";
            dataGridViewCellStyle35.NullValue = null;
            this.dataGridViewTextBoxColumn4.DefaultCellStyle = dataGridViewCellStyle35;
            this.dataGridViewTextBoxColumn4.HeaderText = "Cantidad Javas";
            this.dataGridViewTextBoxColumn4.MaxInputLength = 4;
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn4.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn4.Width = 70;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "PesoJava";
            dataGridViewCellStyle36.Format = "N2";
            dataGridViewCellStyle36.NullValue = null;
            this.dataGridViewTextBoxColumn5.DefaultCellStyle = dataGridViewCellStyle36;
            this.dataGridViewTextBoxColumn5.HeaderText = "Peso Javas";
            this.dataGridViewTextBoxColumn5.MaxInputLength = 11;
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn5.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn5.Width = 70;
            // 
            // dataGridViewTextBoxColumn6
            // 
            dataGridViewCellStyle37.Format = "N2";
            dataGridViewCellStyle37.NullValue = null;
            this.dataGridViewTextBoxColumn6.DefaultCellStyle = dataGridViewCellStyle37;
            this.dataGridViewTextBoxColumn6.HeaderText = "Peso Bruto";
            this.dataGridViewTextBoxColumn6.MaxInputLength = 11;
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn6.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn6.Width = 70;
            // 
            // dataGridViewTextBoxColumn7
            // 
            dataGridViewCellStyle38.Format = "N2";
            dataGridViewCellStyle38.NullValue = null;
            this.dataGridViewTextBoxColumn7.DefaultCellStyle = dataGridViewCellStyle38;
            this.dataGridViewTextBoxColumn7.HeaderText = "Peso Tara";
            this.dataGridViewTextBoxColumn7.MaxInputLength = 11;
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn7.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn7.Width = 70;
            // 
            // dataGridViewTextBoxColumn8
            // 
            dataGridViewCellStyle39.Format = "N2";
            dataGridViewCellStyle39.NullValue = null;
            this.dataGridViewTextBoxColumn8.DefaultCellStyle = dataGridViewCellStyle39;
            this.dataGridViewTextBoxColumn8.HeaderText = "Peso Neto";
            this.dataGridViewTextBoxColumn8.MaxInputLength = 11;
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            this.dataGridViewTextBoxColumn8.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn8.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn8.Width = 70;
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "Observacion";
            this.dataGridViewTextBoxColumn9.HeaderText = "Observación";
            this.dataGridViewTextBoxColumn9.MaxInputLength = 200;
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            this.dataGridViewTextBoxColumn9.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn9.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn9.Width = 250;
            // 
            // frmDevoluciones
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(976, 320);
            this.Controls.Add(this.groupBox1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmDevoluciones";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "DGP - Devoluciones";
            this.Load += new System.EventHandler(this.frmDevoluciones_Load);
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgrvDevolucion)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox cbCliente;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cbVenta;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnAceptarDevolucion;
        private System.Windows.Forms.Label lblTotalNeto;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblTotalBruto;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lblTotalTara;
        private System.Windows.Forms.DataGridView dgrvDevolucion;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lblProducto;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.Label lblPrecio;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column00;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column01;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column02;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column03;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column04;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column05;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column06;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column07;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column08;
        private System.Windows.Forms.DataGridViewButtonColumn Column09;
    }
}