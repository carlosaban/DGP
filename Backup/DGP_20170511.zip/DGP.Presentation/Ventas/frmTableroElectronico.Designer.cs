﻿namespace DGP.Presentation.Ventas
{
    partial class frmTableroElectronico
    {
        /// <summary>
        /// Variable del diseñador requerida.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén utilizando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben eliminar; false en caso contrario, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido del método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle26 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle33 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle27 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle28 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle29 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle30 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle31 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle32 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle34 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle35 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle39 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle36 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle37 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle38 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmTableroElectronico));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle40 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle41 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle42 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle43 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle44 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle45 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle46 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle47 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle48 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle49 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle50 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tcTableroElectronico = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label6 = new System.Windows.Forms.Label();
            this.lblMontoDia = new System.Windows.Forms.Label();
            this.lblAnteriores = new System.Windows.Forms.Label();
            this.lblCongelados = new System.Windows.Forms.Label();
            this.nudAmortizacion = new System.Windows.Forms.NumericUpDown();
            this.label10 = new System.Windows.Forms.Label();
            this.nudCantidad = new System.Windows.Forms.NumericUpDown();
            this.chkbAlContado = new System.Windows.Forms.CheckBox();
            this.label9 = new System.Windows.Forms.Label();
            this.dtpFechaCaja = new System.Windows.Forms.DateTimePicker();
            this.dgvLineaVenta = new System.Windows.Forms.DataGridView();
            this.Column00 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column02 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column01 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column03 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column04 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column05 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column06 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column07 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CantidadPollos = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column08 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column09 = new System.Windows.Forms.DataGridViewButtonColumn();
            this.nudPredio = new System.Windows.Forms.NumericUpDown();
            this.cbEmpresa = new System.Windows.Forms.ComboBox();
            this.label19 = new System.Windows.Forms.Label();
            this.txtNroDocumento = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.cbTipoDocumento = new System.Windows.Forms.ComboBox();
            this.label15 = new System.Windows.Forms.Label();
            this.cbVenta = new System.Windows.Forms.ComboBox();
            this.label14 = new System.Windows.Forms.Label();
            this.btnAceptarVenta = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.lblMonto = new System.Windows.Forms.Label();
            this.lblTotalPesoNeto = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.lblTotalPesoTara = new System.Windows.Forms.Label();
            this.lblTotalPesoBruto = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.txtObservacionesVenta = new System.Windows.Forms.TextBox();
            this.lblSimboloMoneda = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.ckbEsSobrante = new System.Windows.Forms.CheckBox();
            this.cbProducto = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.cbCliente = new System.Windows.Forms.ComboBox();
            this.cbZona = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnBuscar = new System.Windows.Forms.Button();
            this.cbClienteB = new System.Windows.Forms.ComboBox();
            this.cbProductoB = new System.Windows.Forms.ComboBox();
            this.cbZonaB = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.dgvListaVenta = new System.Windows.Forms.DataGridView();
            this.dglColumn00 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dglColumn01 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dglColumn02 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dglColumn03 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dglColumn04 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dglColumn05 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dglColumn07 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dglColumn06 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dglColumn08 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dglColumn09 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dglColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dglColumn14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dglColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dglColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.verCuenta = new System.Windows.Forms.DataGridViewButtonColumn();
            this.dglColumn11 = new System.Windows.Forms.DataGridViewButtonColumn();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.txtGastoConcepto = new System.Windows.Forms.TextBox();
            this.NudGastoMonto = new System.Windows.Forms.NumericUpDown();
            this.txtGastoObservacion = new System.Windows.Forms.TextBox();
            this.cmbTipoGasto = new System.Windows.Forms.ComboBox();
            this.bdsTipoGasto = new System.Windows.Forms.BindingSource(this.components);
            this.btnAceptarGasto = new System.Windows.Forms.Button();
            this.dgvGastos = new System.Windows.Forms.DataGridView();
            this.bdsGasto = new System.Windows.Forms.BindingSource(this.components);
            this.bdsGasto2 = new System.Windows.Forms.BindingSource(this.components);
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn17 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn18 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn19 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn20 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn21 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn22 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn23 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn24 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn25 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn26 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn27 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn28 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn29 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn30 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn31 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn32 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn33 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn34 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn35 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn36 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn37 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idtipoGastoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.idgastoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.conceptoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.montoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.observacionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.grvGastoEliminar = new System.Windows.Forms.DataGridViewButtonColumn();
            this.tcTableroElectronico.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudAmortizacion)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudCantidad)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvLineaVenta)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudPredio)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvListaVenta)).BeginInit();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NudGastoMonto)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bdsTipoGasto)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvGastos)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bdsGasto)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bdsGasto2)).BeginInit();
            this.SuspendLayout();
            // 
            // tcTableroElectronico
            // 
            this.tcTableroElectronico.Controls.Add(this.tabPage1);
            this.tcTableroElectronico.Controls.Add(this.tabPage2);
            this.tcTableroElectronico.Controls.Add(this.tabPage3);
            resources.ApplyResources(this.tcTableroElectronico, "tcTableroElectronico");
            this.tcTableroElectronico.Name = "tcTableroElectronico";
            this.tcTableroElectronico.SelectedIndex = 0;
            this.tcTableroElectronico.SelectedIndexChanged += new System.EventHandler(this.tcTableroElectronico_SelectedIndexChanged);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.groupBox3);
            this.tabPage1.Controls.Add(this.nudAmortizacion);
            this.tabPage1.Controls.Add(this.label10);
            this.tabPage1.Controls.Add(this.nudCantidad);
            this.tabPage1.Controls.Add(this.chkbAlContado);
            this.tabPage1.Controls.Add(this.label9);
            this.tabPage1.Controls.Add(this.dtpFechaCaja);
            this.tabPage1.Controls.Add(this.dgvLineaVenta);
            this.tabPage1.Controls.Add(this.nudPredio);
            this.tabPage1.Controls.Add(this.cbEmpresa);
            this.tabPage1.Controls.Add(this.label19);
            this.tabPage1.Controls.Add(this.txtNroDocumento);
            this.tabPage1.Controls.Add(this.label18);
            this.tabPage1.Controls.Add(this.cbTipoDocumento);
            this.tabPage1.Controls.Add(this.label15);
            this.tabPage1.Controls.Add(this.cbVenta);
            this.tabPage1.Controls.Add(this.label14);
            this.tabPage1.Controls.Add(this.btnAceptarVenta);
            this.tabPage1.Controls.Add(this.groupBox2);
            this.tabPage1.Controls.Add(this.txtObservacionesVenta);
            this.tabPage1.Controls.Add(this.lblSimboloMoneda);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.ckbEsSobrante);
            this.tabPage1.Controls.Add(this.cbProducto);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.cbCliente);
            this.tabPage1.Controls.Add(this.cbZona);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.label1);
            resources.ApplyResources(this.tabPage1, "tabPage1");
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.lblMontoDia);
            this.groupBox3.Controls.Add(this.lblAnteriores);
            this.groupBox3.Controls.Add(this.lblCongelados);
            resources.ApplyResources(this.groupBox3, "groupBox3");
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.TabStop = false;
            // 
            // label6
            // 
            resources.ApplyResources(this.label6, "label6");
            this.label6.Name = "label6";
            // 
            // lblMontoDia
            // 
            this.lblMontoDia.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            resources.ApplyResources(this.lblMontoDia, "lblMontoDia");
            this.lblMontoDia.Name = "lblMontoDia";
            // 
            // lblAnteriores
            // 
            this.lblAnteriores.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            resources.ApplyResources(this.lblAnteriores, "lblAnteriores");
            this.lblAnteriores.Name = "lblAnteriores";
            // 
            // lblCongelados
            // 
            this.lblCongelados.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            resources.ApplyResources(this.lblCongelados, "lblCongelados");
            this.lblCongelados.Name = "lblCongelados";
            // 
            // nudAmortizacion
            // 
            this.nudAmortizacion.DecimalPlaces = 2;
            this.nudAmortizacion.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            resources.ApplyResources(this.nudAmortizacion, "nudAmortizacion");
            this.nudAmortizacion.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.nudAmortizacion.Name = "nudAmortizacion";
            // 
            // label10
            // 
            resources.ApplyResources(this.label10, "label10");
            this.label10.Name = "label10";
            // 
            // nudCantidad
            // 
            resources.ApplyResources(this.nudCantidad, "nudCantidad");
            this.nudCantidad.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.nudCantidad.Name = "nudCantidad";
            this.nudCantidad.ReadOnly = true;
            // 
            // chkbAlContado
            // 
            resources.ApplyResources(this.chkbAlContado, "chkbAlContado");
            this.chkbAlContado.Name = "chkbAlContado";
            this.chkbAlContado.UseVisualStyleBackColor = true;
            this.chkbAlContado.CheckedChanged += new System.EventHandler(this.chkbAlContado_CheckedChanged);
            // 
            // label9
            // 
            resources.ApplyResources(this.label9, "label9");
            this.label9.Name = "label9";
            // 
            // dtpFechaCaja
            // 
            resources.ApplyResources(this.dtpFechaCaja, "dtpFechaCaja");
            this.dtpFechaCaja.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpFechaCaja.Name = "dtpFechaCaja";
            // 
            // dgvLineaVenta
            // 
            this.dgvLineaVenta.AllowUserToAddRows = false;
            this.dgvLineaVenta.AllowUserToDeleteRows = false;
            this.dgvLineaVenta.AllowUserToResizeColumns = false;
            this.dgvLineaVenta.AllowUserToResizeRows = false;
            dataGridViewCellStyle26.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle26.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle26.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            dataGridViewCellStyle26.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle26.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle26.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle26.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvLineaVenta.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle26;
            this.dgvLineaVenta.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvLineaVenta.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column00,
            this.Column02,
            this.Column01,
            this.Column03,
            this.Column04,
            this.Column05,
            this.Column06,
            this.Column07,
            this.CantidadPollos,
            this.Column08,
            this.Column09});
            resources.ApplyResources(this.dgvLineaVenta, "dgvLineaVenta");
            this.dgvLineaVenta.MultiSelect = false;
            this.dgvLineaVenta.Name = "dgvLineaVenta";
            this.dgvLineaVenta.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dataGridViewCellStyle33.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvLineaVenta.RowsDefaultCellStyle = dataGridViewCellStyle33;
            this.dgvLineaVenta.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvLineaVenta.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgvLineaVenta_CellMouseClick);
            this.dgvLineaVenta.CellBeginEdit += new System.Windows.Forms.DataGridViewCellCancelEventHandler(this.dgvLineaVenta_CellBeginEdit);
            this.dgvLineaVenta.RowsAdded += new System.Windows.Forms.DataGridViewRowsAddedEventHandler(this.dgvLineaVenta_RowsAdded);
            this.dgvLineaVenta.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvLineaVenta_CellEndEdit);
            this.dgvLineaVenta.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtTABToENTER_KeyPress);
            this.dgvLineaVenta.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvLineaVenta_CellContentClick);
            // 
            // Column00
            // 
            resources.ApplyResources(this.Column00, "Column00");
            this.Column00.Name = "Column00";
            this.Column00.ReadOnly = true;
            this.Column00.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Column00.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // Column02
            // 
            resources.ApplyResources(this.Column02, "Column02");
            this.Column02.Name = "Column02";
            this.Column02.ReadOnly = true;
            this.Column02.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Column02.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // Column01
            // 
            resources.ApplyResources(this.Column01, "Column01");
            this.Column01.MaxInputLength = 11;
            this.Column01.Name = "Column01";
            this.Column01.ReadOnly = true;
            this.Column01.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Column01.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // Column03
            // 
            this.Column03.DataPropertyName = "CantidadJavas";
            dataGridViewCellStyle27.Format = "N0";
            dataGridViewCellStyle27.NullValue = null;
            this.Column03.DefaultCellStyle = dataGridViewCellStyle27;
            resources.ApplyResources(this.Column03, "Column03");
            this.Column03.MaxInputLength = 4;
            this.Column03.Name = "Column03";
            this.Column03.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Column03.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // Column04
            // 
            this.Column04.DataPropertyName = "PesoJava";
            dataGridViewCellStyle28.Format = "N2";
            dataGridViewCellStyle28.NullValue = null;
            this.Column04.DefaultCellStyle = dataGridViewCellStyle28;
            resources.ApplyResources(this.Column04, "Column04");
            this.Column04.MaxInputLength = 11;
            this.Column04.Name = "Column04";
            this.Column04.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Column04.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // Column05
            // 
            dataGridViewCellStyle29.Format = "N2";
            dataGridViewCellStyle29.NullValue = null;
            this.Column05.DefaultCellStyle = dataGridViewCellStyle29;
            resources.ApplyResources(this.Column05, "Column05");
            this.Column05.MaxInputLength = 11;
            this.Column05.Name = "Column05";
            this.Column05.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Column05.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // Column06
            // 
            dataGridViewCellStyle30.Format = "N2";
            dataGridViewCellStyle30.NullValue = null;
            this.Column06.DefaultCellStyle = dataGridViewCellStyle30;
            resources.ApplyResources(this.Column06, "Column06");
            this.Column06.MaxInputLength = 11;
            this.Column06.Name = "Column06";
            this.Column06.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Column06.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // Column07
            // 
            dataGridViewCellStyle31.Format = "N2";
            dataGridViewCellStyle31.NullValue = null;
            this.Column07.DefaultCellStyle = dataGridViewCellStyle31;
            resources.ApplyResources(this.Column07, "Column07");
            this.Column07.MaxInputLength = 11;
            this.Column07.Name = "Column07";
            this.Column07.ReadOnly = true;
            this.Column07.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Column07.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // CantidadPollos
            // 
            resources.ApplyResources(this.CantidadPollos, "CantidadPollos");
            this.CantidadPollos.Name = "CantidadPollos";
            // 
            // Column08
            // 
            this.Column08.DataPropertyName = "Observacion";
            resources.ApplyResources(this.Column08, "Column08");
            this.Column08.MaxInputLength = 200;
            this.Column08.Name = "Column08";
            this.Column08.ReadOnly = true;
            this.Column08.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Column08.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // Column09
            // 
            dataGridViewCellStyle32.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle32.BackColor = System.Drawing.Color.WhiteSmoke;
            dataGridViewCellStyle32.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle32.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle32.SelectionBackColor = System.Drawing.Color.Gray;
            this.Column09.DefaultCellStyle = dataGridViewCellStyle32;
            resources.ApplyResources(this.Column09, "Column09");
            this.Column09.Name = "Column09";
            this.Column09.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Column09.Text = "Eliminar";
            this.Column09.UseColumnTextForButtonValue = true;
            // 
            // nudPredio
            // 
            this.nudPredio.DecimalPlaces = 2;
            this.nudPredio.Increment = new decimal(new int[] {
            5,
            0,
            0,
            131072});
            resources.ApplyResources(this.nudPredio, "nudPredio");
            this.nudPredio.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.nudPredio.Name = "nudPredio";
            this.nudPredio.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudPredio.ValueChanged += new System.EventHandler(this.nudPredio_ValueChanged);
            this.nudPredio.Leave += new System.EventHandler(this.nudPredio_Leave);
            this.nudPredio.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtTABToENTER_KeyPress);
            // 
            // cbEmpresa
            // 
            this.cbEmpresa.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbEmpresa.FormattingEnabled = true;
            resources.ApplyResources(this.cbEmpresa, "cbEmpresa");
            this.cbEmpresa.Name = "cbEmpresa";
            this.cbEmpresa.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtTABToENTER_KeyPress);
            // 
            // label19
            // 
            resources.ApplyResources(this.label19, "label19");
            this.label19.Name = "label19";
            // 
            // txtNroDocumento
            // 
            resources.ApplyResources(this.txtNroDocumento, "txtNroDocumento");
            this.txtNroDocumento.Name = "txtNroDocumento";
            this.txtNroDocumento.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtTABToENTER_KeyPress);
            // 
            // label18
            // 
            resources.ApplyResources(this.label18, "label18");
            this.label18.Name = "label18";
            // 
            // cbTipoDocumento
            // 
            this.cbTipoDocumento.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbTipoDocumento.FormattingEnabled = true;
            resources.ApplyResources(this.cbTipoDocumento, "cbTipoDocumento");
            this.cbTipoDocumento.Name = "cbTipoDocumento";
            this.cbTipoDocumento.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtTABToENTER_KeyPress);
            // 
            // label15
            // 
            resources.ApplyResources(this.label15, "label15");
            this.label15.Name = "label15";
            // 
            // cbVenta
            // 
            this.cbVenta.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbVenta.FormattingEnabled = true;
            resources.ApplyResources(this.cbVenta, "cbVenta");
            this.cbVenta.Name = "cbVenta";
            this.cbVenta.SelectedIndexChanged += new System.EventHandler(this.cbVenta_SelectedIndexChanged);
            this.cbVenta.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtTABToENTER_KeyPress);
            // 
            // label14
            // 
            resources.ApplyResources(this.label14, "label14");
            this.label14.Name = "label14";
            // 
            // btnAceptarVenta
            // 
            resources.ApplyResources(this.btnAceptarVenta, "btnAceptarVenta");
            this.btnAceptarVenta.Name = "btnAceptarVenta";
            this.btnAceptarVenta.UseVisualStyleBackColor = true;
            this.btnAceptarVenta.Click += new System.EventHandler(this.btnAceptarVenta_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.lblMonto);
            this.groupBox2.Controls.Add(this.lblTotalPesoNeto);
            this.groupBox2.Controls.Add(this.label17);
            this.groupBox2.Controls.Add(this.label16);
            this.groupBox2.Controls.Add(this.lblTotalPesoTara);
            this.groupBox2.Controls.Add(this.lblTotalPesoBruto);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.label12);
            resources.ApplyResources(this.groupBox2, "groupBox2");
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.TabStop = false;
            // 
            // lblMonto
            // 
            this.lblMonto.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            resources.ApplyResources(this.lblMonto, "lblMonto");
            this.lblMonto.Name = "lblMonto";
            // 
            // lblTotalPesoNeto
            // 
            this.lblTotalPesoNeto.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            resources.ApplyResources(this.lblTotalPesoNeto, "lblTotalPesoNeto");
            this.lblTotalPesoNeto.Name = "lblTotalPesoNeto";
            // 
            // label17
            // 
            resources.ApplyResources(this.label17, "label17");
            this.label17.Name = "label17";
            // 
            // label16
            // 
            resources.ApplyResources(this.label16, "label16");
            this.label16.Name = "label16";
            // 
            // lblTotalPesoTara
            // 
            this.lblTotalPesoTara.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            resources.ApplyResources(this.lblTotalPesoTara, "lblTotalPesoTara");
            this.lblTotalPesoTara.Name = "lblTotalPesoTara";
            // 
            // lblTotalPesoBruto
            // 
            this.lblTotalPesoBruto.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            resources.ApplyResources(this.lblTotalPesoBruto, "lblTotalPesoBruto");
            this.lblTotalPesoBruto.Name = "lblTotalPesoBruto";
            // 
            // label13
            // 
            resources.ApplyResources(this.label13, "label13");
            this.label13.Name = "label13";
            // 
            // label12
            // 
            resources.ApplyResources(this.label12, "label12");
            this.label12.Name = "label12";
            // 
            // txtObservacionesVenta
            // 
            resources.ApplyResources(this.txtObservacionesVenta, "txtObservacionesVenta");
            this.txtObservacionesVenta.Name = "txtObservacionesVenta";
            this.txtObservacionesVenta.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtTABToENTER_KeyPress);
            // 
            // lblSimboloMoneda
            // 
            resources.ApplyResources(this.lblSimboloMoneda, "lblSimboloMoneda");
            this.lblSimboloMoneda.Name = "lblSimboloMoneda";
            // 
            // label4
            // 
            resources.ApplyResources(this.label4, "label4");
            this.label4.Name = "label4";
            // 
            // ckbEsSobrante
            // 
            resources.ApplyResources(this.ckbEsSobrante, "ckbEsSobrante");
            this.ckbEsSobrante.Name = "ckbEsSobrante";
            this.ckbEsSobrante.UseVisualStyleBackColor = true;
            this.ckbEsSobrante.CheckedChanged += new System.EventHandler(this.ckbEsSobrante_CheckedChanged);
            // 
            // cbProducto
            // 
            this.cbProducto.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbProducto.FormattingEnabled = true;
            resources.ApplyResources(this.cbProducto, "cbProducto");
            this.cbProducto.Name = "cbProducto";
            this.cbProducto.SelectedIndexChanged += new System.EventHandler(this.cbProducto_SelectedIndexChanged);
            this.cbProducto.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtTABToENTER_KeyPress);
            // 
            // label3
            // 
            resources.ApplyResources(this.label3, "label3");
            this.label3.Name = "label3";
            // 
            // cbCliente
            // 
            this.cbCliente.FormattingEnabled = true;
            resources.ApplyResources(this.cbCliente, "cbCliente");
            this.cbCliente.Name = "cbCliente";
            this.cbCliente.SelectedIndexChanged += new System.EventHandler(this.cbCliente_SelectedIndexChanged);
            this.cbCliente.Leave += new System.EventHandler(this.cbCliente_Leave);
            this.cbCliente.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtTABToENTER_KeyPress);
            this.cbCliente.KeyUp += new System.Windows.Forms.KeyEventHandler(this.cbCliente_KeyUp);
            // 
            // cbZona
            // 
            this.cbZona.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            resources.ApplyResources(this.cbZona, "cbZona");
            this.cbZona.Name = "cbZona";
            this.cbZona.SelectedIndexChanged += new System.EventHandler(this.cbZona_SelectedIndexChanged);
            this.cbZona.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtTABToENTER_KeyPress);
            // 
            // label2
            // 
            resources.ApplyResources(this.label2, "label2");
            this.label2.Name = "label2";
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.Name = "label1";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.groupBox1);
            this.tabPage2.Controls.Add(this.dgvListaVenta);
            resources.ApplyResources(this.tabPage2, "tabPage2");
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnBuscar);
            this.groupBox1.Controls.Add(this.cbClienteB);
            this.groupBox1.Controls.Add(this.cbProductoB);
            this.groupBox1.Controls.Add(this.cbZonaB);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label5);
            resources.ApplyResources(this.groupBox1, "groupBox1");
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.TabStop = false;
            // 
            // btnBuscar
            // 
            resources.ApplyResources(this.btnBuscar, "btnBuscar");
            this.btnBuscar.Name = "btnBuscar";
            this.btnBuscar.UseVisualStyleBackColor = true;
            this.btnBuscar.Click += new System.EventHandler(this.btnBuscar_Click);
            // 
            // cbClienteB
            // 
            this.cbClienteB.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbClienteB.FormattingEnabled = true;
            resources.ApplyResources(this.cbClienteB, "cbClienteB");
            this.cbClienteB.Name = "cbClienteB";
            // 
            // cbProductoB
            // 
            this.cbProductoB.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbProductoB.FormattingEnabled = true;
            resources.ApplyResources(this.cbProductoB, "cbProductoB");
            this.cbProductoB.Name = "cbProductoB";
            // 
            // cbZonaB
            // 
            this.cbZonaB.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbZonaB.FormattingEnabled = true;
            resources.ApplyResources(this.cbZonaB, "cbZonaB");
            this.cbZonaB.Name = "cbZonaB";
            // 
            // label8
            // 
            resources.ApplyResources(this.label8, "label8");
            this.label8.Name = "label8";
            // 
            // label7
            // 
            resources.ApplyResources(this.label7, "label7");
            this.label7.Name = "label7";
            // 
            // label5
            // 
            resources.ApplyResources(this.label5, "label5");
            this.label5.Name = "label5";
            // 
            // dgvListaVenta
            // 
            this.dgvListaVenta.AllowUserToAddRows = false;
            this.dgvListaVenta.AllowUserToDeleteRows = false;
            dataGridViewCellStyle34.SelectionBackColor = System.Drawing.Color.White;
            dataGridViewCellStyle34.SelectionForeColor = System.Drawing.Color.Black;
            this.dgvListaVenta.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle34;
            dataGridViewCellStyle35.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle35.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle35.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            dataGridViewCellStyle35.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle35.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle35.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle35.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvListaVenta.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle35;
            this.dgvListaVenta.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvListaVenta.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dglColumn00,
            this.dglColumn01,
            this.dglColumn02,
            this.dglColumn03,
            this.dglColumn04,
            this.dglColumn05,
            this.dglColumn07,
            this.dglColumn06,
            this.dglColumn08,
            this.dglColumn09,
            this.dglColumn10,
            this.dglColumn14,
            this.dglColumn12,
            this.dglColumn13,
            this.verCuenta,
            this.dglColumn11});
            resources.ApplyResources(this.dgvListaVenta, "dgvListaVenta");
            this.dgvListaVenta.MultiSelect = false;
            this.dgvListaVenta.Name = "dgvListaVenta";
            this.dgvListaVenta.RowHeadersVisible = false;
            this.dgvListaVenta.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dataGridViewCellStyle39.SelectionBackColor = System.Drawing.Color.White;
            dataGridViewCellStyle39.SelectionForeColor = System.Drawing.Color.Black;
            this.dgvListaVenta.RowsDefaultCellStyle = dataGridViewCellStyle39;
            this.dgvListaVenta.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvListaVenta.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvListaVenta_CellEndEdit);
            this.dgvListaVenta.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvListaVenta_CellContentClick);
            // 
            // dglColumn00
            // 
            this.dglColumn00.DataPropertyName = "IdVenta";
            dataGridViewCellStyle36.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dglColumn00.DefaultCellStyle = dataGridViewCellStyle36;
            resources.ApplyResources(this.dglColumn00, "dglColumn00");
            this.dglColumn00.Name = "dglColumn00";
            this.dglColumn00.ReadOnly = true;
            this.dglColumn00.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dglColumn00.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dglColumn01
            // 
            this.dglColumn01.DataPropertyName = "Fecha";
            dataGridViewCellStyle37.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dglColumn01.DefaultCellStyle = dataGridViewCellStyle37;
            resources.ApplyResources(this.dglColumn01, "dglColumn01");
            this.dglColumn01.Name = "dglColumn01";
            this.dglColumn01.ReadOnly = true;
            this.dglColumn01.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dglColumn01.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dglColumn02
            // 
            this.dglColumn02.DataPropertyName = "Cliente";
            dataGridViewCellStyle38.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dglColumn02.DefaultCellStyle = dataGridViewCellStyle38;
            resources.ApplyResources(this.dglColumn02, "dglColumn02");
            this.dglColumn02.Name = "dglColumn02";
            this.dglColumn02.ReadOnly = true;
            this.dglColumn02.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dglColumn02.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dglColumn03
            // 
            this.dglColumn03.DataPropertyName = "Producto";
            resources.ApplyResources(this.dglColumn03, "dglColumn03");
            this.dglColumn03.Name = "dglColumn03";
            this.dglColumn03.ReadOnly = true;
            this.dglColumn03.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dglColumn03.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dglColumn04
            // 
            this.dglColumn04.DataPropertyName = "TotalPesoBruto";
            resources.ApplyResources(this.dglColumn04, "dglColumn04");
            this.dglColumn04.Name = "dglColumn04";
            this.dglColumn04.ReadOnly = true;
            this.dglColumn04.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dglColumn04.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dglColumn05
            // 
            this.dglColumn05.DataPropertyName = "TotalPesoTara";
            resources.ApplyResources(this.dglColumn05, "dglColumn05");
            this.dglColumn05.Name = "dglColumn05";
            this.dglColumn05.ReadOnly = true;
            this.dglColumn05.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dglColumn05.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dglColumn07
            // 
            this.dglColumn07.DataPropertyName = "TotalDevolucion";
            resources.ApplyResources(this.dglColumn07, "dglColumn07");
            this.dglColumn07.Name = "dglColumn07";
            this.dglColumn07.ReadOnly = true;
            this.dglColumn07.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dglColumn07.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dglColumn06
            // 
            this.dglColumn06.DataPropertyName = "TotalPesoNeto";
            resources.ApplyResources(this.dglColumn06, "dglColumn06");
            this.dglColumn06.Name = "dglColumn06";
            this.dglColumn06.ReadOnly = true;
            this.dglColumn06.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dglColumn06.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dglColumn08
            // 
            this.dglColumn08.DataPropertyName = "MontoTotal";
            resources.ApplyResources(this.dglColumn08, "dglColumn08");
            this.dglColumn08.Name = "dglColumn08";
            this.dglColumn08.ReadOnly = true;
            this.dglColumn08.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dglColumn09
            // 
            this.dglColumn09.DataPropertyName = "TotalSaldo";
            resources.ApplyResources(this.dglColumn09, "dglColumn09");
            this.dglColumn09.Name = "dglColumn09";
            this.dglColumn09.ReadOnly = true;
            this.dglColumn09.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dglColumn10
            // 
            resources.ApplyResources(this.dglColumn10, "dglColumn10");
            this.dglColumn10.Name = "dglColumn10";
            this.dglColumn10.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dglColumn10.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dglColumn14
            // 
            this.dglColumn14.DataPropertyName = "IdEstado";
            resources.ApplyResources(this.dglColumn14, "dglColumn14");
            this.dglColumn14.Name = "dglColumn14";
            this.dglColumn14.ReadOnly = true;
            this.dglColumn14.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dglColumn14.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dglColumn12
            // 
            this.dglColumn12.DataPropertyName = "IdCliente";
            resources.ApplyResources(this.dglColumn12, "dglColumn12");
            this.dglColumn12.Name = "dglColumn12";
            this.dglColumn12.ReadOnly = true;
            this.dglColumn12.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dglColumn12.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dglColumn13
            // 
            this.dglColumn13.DataPropertyName = "IdEsSobrante";
            resources.ApplyResources(this.dglColumn13, "dglColumn13");
            this.dglColumn13.Name = "dglColumn13";
            this.dglColumn13.ReadOnly = true;
            this.dglColumn13.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dglColumn13.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // verCuenta
            // 
            resources.ApplyResources(this.verCuenta, "verCuenta");
            this.verCuenta.Name = "verCuenta";
            // 
            // dglColumn11
            // 
            resources.ApplyResources(this.dglColumn11, "dglColumn11");
            this.dglColumn11.Name = "dglColumn11";
            this.dglColumn11.ReadOnly = true;
            this.dglColumn11.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dglColumn11.Text = "Pagar";
            this.dglColumn11.UseColumnTextForButtonValue = true;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.txtGastoConcepto);
            this.tabPage3.Controls.Add(this.NudGastoMonto);
            this.tabPage3.Controls.Add(this.txtGastoObservacion);
            this.tabPage3.Controls.Add(this.cmbTipoGasto);
            this.tabPage3.Controls.Add(this.btnAceptarGasto);
            this.tabPage3.Controls.Add(this.dgvGastos);
            resources.ApplyResources(this.tabPage3, "tabPage3");
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.UseVisualStyleBackColor = true;
            this.tabPage3.Click += new System.EventHandler(this.tabPage3_Click);
            // 
            // txtGastoConcepto
            // 
            resources.ApplyResources(this.txtGastoConcepto, "txtGastoConcepto");
            this.txtGastoConcepto.Name = "txtGastoConcepto";
            this.txtGastoConcepto.TextChanged += new System.EventHandler(this.txtConcepto_TextChanged);
            // 
            // NudGastoMonto
            // 
            resources.ApplyResources(this.NudGastoMonto, "NudGastoMonto");
            this.NudGastoMonto.Name = "NudGastoMonto";
            // 
            // txtGastoObservacion
            // 
            resources.ApplyResources(this.txtGastoObservacion, "txtGastoObservacion");
            this.txtGastoObservacion.Name = "txtGastoObservacion";
            // 
            // cmbTipoGasto
            // 
            this.cmbTipoGasto.DataSource = this.bdsTipoGasto;
            this.cmbTipoGasto.DisplayMember = "Descripcion";
            this.cmbTipoGasto.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTipoGasto.FormattingEnabled = true;
            resources.ApplyResources(this.cmbTipoGasto, "cmbTipoGasto");
            this.cmbTipoGasto.Name = "cmbTipoGasto";
            this.cmbTipoGasto.ValueMember = "id_Tipo_Gasto";
            this.cmbTipoGasto.SelectedIndexChanged += new System.EventHandler(this.cmbTipoGasto_SelectedIndexChanged);
            this.cmbTipoGasto.Enter += new System.EventHandler(this.cmbTipoGasto_Enter);
            // 
            // bdsTipoGasto
            // 
            this.bdsTipoGasto.DataSource = typeof(DGP.Entities.DataSet.DSEntitiesTablero.Tb_Tipo_GastoDataTable);
            // 
            // btnAceptarGasto
            // 
            resources.ApplyResources(this.btnAceptarGasto, "btnAceptarGasto");
            this.btnAceptarGasto.Name = "btnAceptarGasto";
            this.btnAceptarGasto.UseVisualStyleBackColor = true;
            this.btnAceptarGasto.Click += new System.EventHandler(this.btnAceptar_Click);
            // 
            // dgvGastos
            // 
            this.dgvGastos.AllowUserToAddRows = false;
            this.dgvGastos.AllowUserToDeleteRows = false;
            this.dgvGastos.AllowUserToResizeColumns = false;
            this.dgvGastos.AutoGenerateColumns = false;
            this.dgvGastos.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvGastos.CausesValidation = false;
            this.dgvGastos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvGastos.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idtipoGastoDataGridViewTextBoxColumn,
            this.idgastoDataGridViewTextBoxColumn,
            this.conceptoDataGridViewTextBoxColumn,
            this.montoDataGridViewTextBoxColumn,
            this.observacionDataGridViewTextBoxColumn,
            this.grvGastoEliminar});
            this.dgvGastos.DataSource = this.bdsGasto;
            resources.ApplyResources(this.dgvGastos, "dgvGastos");
            this.dgvGastos.Name = "dgvGastos";
            this.dgvGastos.ReadOnly = true;
            this.dgvGastos.StandardTab = true;
            this.dgvGastos.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvGastos_CellContentClick);
            // 
            // bdsGasto
            // 
            this.bdsGasto.DataSource = typeof(DGP.Entities.DataSet.DSEntitiesTablero.tb_gastoDataTable);
            // 
            // bdsGasto2
            // 
            this.bdsGasto2.DataSource = typeof(DGP.Entities.DataSet.DSEntitiesTablero.tb_gastoDataTable);
            // 
            // dataGridViewTextBoxColumn1
            // 
            resources.ApplyResources(this.dataGridViewTextBoxColumn1, "dataGridViewTextBoxColumn1");
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dataGridViewTextBoxColumn2
            // 
            resources.ApplyResources(this.dataGridViewTextBoxColumn2, "dataGridViewTextBoxColumn2");
            this.dataGridViewTextBoxColumn2.MaxInputLength = 11;
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dataGridViewTextBoxColumn3
            // 
            resources.ApplyResources(this.dataGridViewTextBoxColumn3, "dataGridViewTextBoxColumn3");
            this.dataGridViewTextBoxColumn3.MaxInputLength = 11;
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "CantidadJavas";
            dataGridViewCellStyle40.Format = "N0";
            dataGridViewCellStyle40.NullValue = null;
            this.dataGridViewTextBoxColumn4.DefaultCellStyle = dataGridViewCellStyle40;
            resources.ApplyResources(this.dataGridViewTextBoxColumn4, "dataGridViewTextBoxColumn4");
            this.dataGridViewTextBoxColumn4.MaxInputLength = 4;
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn4.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "PesoJava";
            dataGridViewCellStyle41.Format = "N2";
            dataGridViewCellStyle41.NullValue = null;
            this.dataGridViewTextBoxColumn5.DefaultCellStyle = dataGridViewCellStyle41;
            resources.ApplyResources(this.dataGridViewTextBoxColumn5, "dataGridViewTextBoxColumn5");
            this.dataGridViewTextBoxColumn5.MaxInputLength = 11;
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn5.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dataGridViewTextBoxColumn6
            // 
            dataGridViewCellStyle42.Format = "N2";
            dataGridViewCellStyle42.NullValue = null;
            this.dataGridViewTextBoxColumn6.DefaultCellStyle = dataGridViewCellStyle42;
            resources.ApplyResources(this.dataGridViewTextBoxColumn6, "dataGridViewTextBoxColumn6");
            this.dataGridViewTextBoxColumn6.MaxInputLength = 11;
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn6.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dataGridViewTextBoxColumn7
            // 
            dataGridViewCellStyle43.Format = "N2";
            dataGridViewCellStyle43.NullValue = null;
            this.dataGridViewTextBoxColumn7.DefaultCellStyle = dataGridViewCellStyle43;
            resources.ApplyResources(this.dataGridViewTextBoxColumn7, "dataGridViewTextBoxColumn7");
            this.dataGridViewTextBoxColumn7.MaxInputLength = 11;
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn7.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dataGridViewTextBoxColumn8
            // 
            dataGridViewCellStyle44.Format = "N2";
            dataGridViewCellStyle44.NullValue = null;
            this.dataGridViewTextBoxColumn8.DefaultCellStyle = dataGridViewCellStyle44;
            resources.ApplyResources(this.dataGridViewTextBoxColumn8, "dataGridViewTextBoxColumn8");
            this.dataGridViewTextBoxColumn8.MaxInputLength = 11;
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            this.dataGridViewTextBoxColumn8.ReadOnly = true;
            this.dataGridViewTextBoxColumn8.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn8.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "Observacion";
            resources.ApplyResources(this.dataGridViewTextBoxColumn9, "dataGridViewTextBoxColumn9");
            this.dataGridViewTextBoxColumn9.MaxInputLength = 200;
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            this.dataGridViewTextBoxColumn9.ReadOnly = true;
            this.dataGridViewTextBoxColumn9.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn9.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.DataPropertyName = "IdVenta";
            dataGridViewCellStyle45.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn10.DefaultCellStyle = dataGridViewCellStyle45;
            this.dataGridViewTextBoxColumn10.Frozen = true;
            resources.ApplyResources(this.dataGridViewTextBoxColumn10, "dataGridViewTextBoxColumn10");
            this.dataGridViewTextBoxColumn10.MaxInputLength = 200;
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            this.dataGridViewTextBoxColumn10.ReadOnly = true;
            this.dataGridViewTextBoxColumn10.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn10.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.DataPropertyName = "IdCliente";
            dataGridViewCellStyle46.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn11.DefaultCellStyle = dataGridViewCellStyle46;
            this.dataGridViewTextBoxColumn11.Frozen = true;
            resources.ApplyResources(this.dataGridViewTextBoxColumn11, "dataGridViewTextBoxColumn11");
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            this.dataGridViewTextBoxColumn11.ReadOnly = true;
            this.dataGridViewTextBoxColumn11.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn11.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.DataPropertyName = "Cliente";
            dataGridViewCellStyle47.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn12.DefaultCellStyle = dataGridViewCellStyle47;
            this.dataGridViewTextBoxColumn12.Frozen = true;
            resources.ApplyResources(this.dataGridViewTextBoxColumn12, "dataGridViewTextBoxColumn12");
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            this.dataGridViewTextBoxColumn12.ReadOnly = true;
            this.dataGridViewTextBoxColumn12.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn12.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            // 
            // dataGridViewTextBoxColumn13
            // 
            this.dataGridViewTextBoxColumn13.DataPropertyName = "NroDocumento";
            dataGridViewCellStyle48.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn13.DefaultCellStyle = dataGridViewCellStyle48;
            this.dataGridViewTextBoxColumn13.Frozen = true;
            resources.ApplyResources(this.dataGridViewTextBoxColumn13, "dataGridViewTextBoxColumn13");
            this.dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
            this.dataGridViewTextBoxColumn13.ReadOnly = true;
            this.dataGridViewTextBoxColumn13.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn13.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dataGridViewTextBoxColumn14
            // 
            this.dataGridViewTextBoxColumn14.DataPropertyName = "NumeroDocumento";
            dataGridViewCellStyle49.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn14.DefaultCellStyle = dataGridViewCellStyle49;
            resources.ApplyResources(this.dataGridViewTextBoxColumn14, "dataGridViewTextBoxColumn14");
            this.dataGridViewTextBoxColumn14.Name = "dataGridViewTextBoxColumn14";
            this.dataGridViewTextBoxColumn14.ReadOnly = true;
            this.dataGridViewTextBoxColumn14.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn14.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dataGridViewTextBoxColumn15
            // 
            this.dataGridViewTextBoxColumn15.DataPropertyName = "TotalPesoBruto";
            dataGridViewCellStyle50.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn15.DefaultCellStyle = dataGridViewCellStyle50;
            resources.ApplyResources(this.dataGridViewTextBoxColumn15, "dataGridViewTextBoxColumn15");
            this.dataGridViewTextBoxColumn15.Name = "dataGridViewTextBoxColumn15";
            this.dataGridViewTextBoxColumn15.ReadOnly = true;
            this.dataGridViewTextBoxColumn15.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn15.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dataGridViewTextBoxColumn16
            // 
            this.dataGridViewTextBoxColumn16.DataPropertyName = "TotalPesoTara";
            resources.ApplyResources(this.dataGridViewTextBoxColumn16, "dataGridViewTextBoxColumn16");
            this.dataGridViewTextBoxColumn16.Name = "dataGridViewTextBoxColumn16";
            this.dataGridViewTextBoxColumn16.ReadOnly = true;
            this.dataGridViewTextBoxColumn16.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn16.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dataGridViewTextBoxColumn17
            // 
            this.dataGridViewTextBoxColumn17.DataPropertyName = "TotalPesoNeto";
            resources.ApplyResources(this.dataGridViewTextBoxColumn17, "dataGridViewTextBoxColumn17");
            this.dataGridViewTextBoxColumn17.Name = "dataGridViewTextBoxColumn17";
            this.dataGridViewTextBoxColumn17.ReadOnly = true;
            this.dataGridViewTextBoxColumn17.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn17.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dataGridViewTextBoxColumn18
            // 
            this.dataGridViewTextBoxColumn18.DataPropertyName = "TotalDevolucion";
            resources.ApplyResources(this.dataGridViewTextBoxColumn18, "dataGridViewTextBoxColumn18");
            this.dataGridViewTextBoxColumn18.Name = "dataGridViewTextBoxColumn18";
            this.dataGridViewTextBoxColumn18.ReadOnly = true;
            this.dataGridViewTextBoxColumn18.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn18.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dataGridViewTextBoxColumn19
            // 
            this.dataGridViewTextBoxColumn19.DataPropertyName = "MontoTotal";
            resources.ApplyResources(this.dataGridViewTextBoxColumn19, "dataGridViewTextBoxColumn19");
            this.dataGridViewTextBoxColumn19.Name = "dataGridViewTextBoxColumn19";
            this.dataGridViewTextBoxColumn19.ReadOnly = true;
            this.dataGridViewTextBoxColumn19.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn19.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dataGridViewTextBoxColumn20
            // 
            this.dataGridViewTextBoxColumn20.DataPropertyName = "TotalSaldo";
            resources.ApplyResources(this.dataGridViewTextBoxColumn20, "dataGridViewTextBoxColumn20");
            this.dataGridViewTextBoxColumn20.Name = "dataGridViewTextBoxColumn20";
            this.dataGridViewTextBoxColumn20.ReadOnly = true;
            this.dataGridViewTextBoxColumn20.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn20.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dataGridViewTextBoxColumn21
            // 
            this.dataGridViewTextBoxColumn21.DataPropertyName = "TotalSaldo";
            resources.ApplyResources(this.dataGridViewTextBoxColumn21, "dataGridViewTextBoxColumn21");
            this.dataGridViewTextBoxColumn21.Name = "dataGridViewTextBoxColumn21";
            this.dataGridViewTextBoxColumn21.ReadOnly = true;
            this.dataGridViewTextBoxColumn21.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn21.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dataGridViewTextBoxColumn22
            // 
            this.dataGridViewTextBoxColumn22.DataPropertyName = "IdEsSobrante";
            resources.ApplyResources(this.dataGridViewTextBoxColumn22, "dataGridViewTextBoxColumn22");
            this.dataGridViewTextBoxColumn22.Name = "dataGridViewTextBoxColumn22";
            this.dataGridViewTextBoxColumn22.ReadOnly = true;
            this.dataGridViewTextBoxColumn22.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn22.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dataGridViewTextBoxColumn23
            // 
            this.dataGridViewTextBoxColumn23.DataPropertyName = "IdEstado";
            resources.ApplyResources(this.dataGridViewTextBoxColumn23, "dataGridViewTextBoxColumn23");
            this.dataGridViewTextBoxColumn23.Name = "dataGridViewTextBoxColumn23";
            this.dataGridViewTextBoxColumn23.ReadOnly = true;
            this.dataGridViewTextBoxColumn23.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn23.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dataGridViewTextBoxColumn24
            // 
            this.dataGridViewTextBoxColumn24.DataPropertyName = "id_gasto";
            resources.ApplyResources(this.dataGridViewTextBoxColumn24, "dataGridViewTextBoxColumn24");
            this.dataGridViewTextBoxColumn24.Name = "dataGridViewTextBoxColumn24";
            this.dataGridViewTextBoxColumn24.ReadOnly = true;
            this.dataGridViewTextBoxColumn24.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn24.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dataGridViewTextBoxColumn25
            // 
            this.dataGridViewTextBoxColumn25.DataPropertyName = "id_personal";
            resources.ApplyResources(this.dataGridViewTextBoxColumn25, "dataGridViewTextBoxColumn25");
            this.dataGridViewTextBoxColumn25.Name = "dataGridViewTextBoxColumn25";
            // 
            // dataGridViewTextBoxColumn26
            // 
            this.dataGridViewTextBoxColumn26.DataPropertyName = "id_caja";
            resources.ApplyResources(this.dataGridViewTextBoxColumn26, "dataGridViewTextBoxColumn26");
            this.dataGridViewTextBoxColumn26.Name = "dataGridViewTextBoxColumn26";
            // 
            // dataGridViewTextBoxColumn27
            // 
            this.dataGridViewTextBoxColumn27.DataPropertyName = "concepto";
            resources.ApplyResources(this.dataGridViewTextBoxColumn27, "dataGridViewTextBoxColumn27");
            this.dataGridViewTextBoxColumn27.Name = "dataGridViewTextBoxColumn27";
            // 
            // dataGridViewTextBoxColumn28
            // 
            this.dataGridViewTextBoxColumn28.DataPropertyName = "monto";
            resources.ApplyResources(this.dataGridViewTextBoxColumn28, "dataGridViewTextBoxColumn28");
            this.dataGridViewTextBoxColumn28.Name = "dataGridViewTextBoxColumn28";
            // 
            // dataGridViewTextBoxColumn29
            // 
            this.dataGridViewTextBoxColumn29.DataPropertyName = "observacion";
            resources.ApplyResources(this.dataGridViewTextBoxColumn29, "dataGridViewTextBoxColumn29");
            this.dataGridViewTextBoxColumn29.Name = "dataGridViewTextBoxColumn29";
            // 
            // dataGridViewTextBoxColumn30
            // 
            this.dataGridViewTextBoxColumn30.DataPropertyName = "id_personal";
            resources.ApplyResources(this.dataGridViewTextBoxColumn30, "dataGridViewTextBoxColumn30");
            this.dataGridViewTextBoxColumn30.Name = "dataGridViewTextBoxColumn30";
            // 
            // dataGridViewTextBoxColumn31
            // 
            this.dataGridViewTextBoxColumn31.DataPropertyName = "id_caja";
            resources.ApplyResources(this.dataGridViewTextBoxColumn31, "dataGridViewTextBoxColumn31");
            this.dataGridViewTextBoxColumn31.Name = "dataGridViewTextBoxColumn31";
            // 
            // dataGridViewTextBoxColumn32
            // 
            this.dataGridViewTextBoxColumn32.DataPropertyName = "monto";
            resources.ApplyResources(this.dataGridViewTextBoxColumn32, "dataGridViewTextBoxColumn32");
            this.dataGridViewTextBoxColumn32.Name = "dataGridViewTextBoxColumn32";
            // 
            // dataGridViewTextBoxColumn33
            // 
            this.dataGridViewTextBoxColumn33.DataPropertyName = "concepto";
            resources.ApplyResources(this.dataGridViewTextBoxColumn33, "dataGridViewTextBoxColumn33");
            this.dataGridViewTextBoxColumn33.Name = "dataGridViewTextBoxColumn33";
            // 
            // dataGridViewTextBoxColumn34
            // 
            this.dataGridViewTextBoxColumn34.DataPropertyName = "observacion";
            resources.ApplyResources(this.dataGridViewTextBoxColumn34, "dataGridViewTextBoxColumn34");
            this.dataGridViewTextBoxColumn34.Name = "dataGridViewTextBoxColumn34";
            // 
            // dataGridViewTextBoxColumn35
            // 
            this.dataGridViewTextBoxColumn35.DataPropertyName = "id_tipo_Gasto";
            resources.ApplyResources(this.dataGridViewTextBoxColumn35, "dataGridViewTextBoxColumn35");
            this.dataGridViewTextBoxColumn35.Name = "dataGridViewTextBoxColumn35";
            // 
            // dataGridViewTextBoxColumn36
            // 
            this.dataGridViewTextBoxColumn36.DataPropertyName = "FilaAgregada";
            resources.ApplyResources(this.dataGridViewTextBoxColumn36, "dataGridViewTextBoxColumn36");
            this.dataGridViewTextBoxColumn36.Name = "dataGridViewTextBoxColumn36";
            // 
            // dataGridViewTextBoxColumn37
            // 
            this.dataGridViewTextBoxColumn37.DataPropertyName = "fecha_gasto";
            resources.ApplyResources(this.dataGridViewTextBoxColumn37, "dataGridViewTextBoxColumn37");
            this.dataGridViewTextBoxColumn37.Name = "dataGridViewTextBoxColumn37";
            // 
            // idtipoGastoDataGridViewTextBoxColumn
            // 
            this.idtipoGastoDataGridViewTextBoxColumn.DataPropertyName = "id_tipo_Gasto";
            this.idtipoGastoDataGridViewTextBoxColumn.DataSource = this.bdsTipoGasto;
            this.idtipoGastoDataGridViewTextBoxColumn.DisplayMember = "Descripcion";
            resources.ApplyResources(this.idtipoGastoDataGridViewTextBoxColumn, "idtipoGastoDataGridViewTextBoxColumn");
            this.idtipoGastoDataGridViewTextBoxColumn.Name = "idtipoGastoDataGridViewTextBoxColumn";
            this.idtipoGastoDataGridViewTextBoxColumn.ReadOnly = true;
            this.idtipoGastoDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.idtipoGastoDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.idtipoGastoDataGridViewTextBoxColumn.ValueMember = "id_Tipo_Gasto";
            // 
            // idgastoDataGridViewTextBoxColumn
            // 
            this.idgastoDataGridViewTextBoxColumn.DataPropertyName = "id_gasto";
            resources.ApplyResources(this.idgastoDataGridViewTextBoxColumn, "idgastoDataGridViewTextBoxColumn");
            this.idgastoDataGridViewTextBoxColumn.Name = "idgastoDataGridViewTextBoxColumn";
            this.idgastoDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // conceptoDataGridViewTextBoxColumn
            // 
            this.conceptoDataGridViewTextBoxColumn.DataPropertyName = "concepto";
            resources.ApplyResources(this.conceptoDataGridViewTextBoxColumn, "conceptoDataGridViewTextBoxColumn");
            this.conceptoDataGridViewTextBoxColumn.Name = "conceptoDataGridViewTextBoxColumn";
            this.conceptoDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // montoDataGridViewTextBoxColumn
            // 
            this.montoDataGridViewTextBoxColumn.DataPropertyName = "monto";
            resources.ApplyResources(this.montoDataGridViewTextBoxColumn, "montoDataGridViewTextBoxColumn");
            this.montoDataGridViewTextBoxColumn.Name = "montoDataGridViewTextBoxColumn";
            this.montoDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // observacionDataGridViewTextBoxColumn
            // 
            this.observacionDataGridViewTextBoxColumn.DataPropertyName = "observacion";
            resources.ApplyResources(this.observacionDataGridViewTextBoxColumn, "observacionDataGridViewTextBoxColumn");
            this.observacionDataGridViewTextBoxColumn.Name = "observacionDataGridViewTextBoxColumn";
            this.observacionDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // grvGastoEliminar
            // 
            resources.ApplyResources(this.grvGastoEliminar, "grvGastoEliminar");
            this.grvGastoEliminar.Name = "grvGastoEliminar";
            this.grvGastoEliminar.ReadOnly = true;
            // 
            // frmTableroElectronico
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tcTableroElectronico);
            this.MaximizeBox = false;
            this.Name = "frmTableroElectronico";
            this.Load += new System.EventHandler(this.frmTableroElectronico_Load);
            this.tcTableroElectronico.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudAmortizacion)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudCantidad)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvLineaVenta)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudPredio)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvListaVenta)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NudGastoMonto)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bdsTipoGasto)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvGastos)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bdsGasto)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bdsGasto2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tcTableroElectronico;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.ComboBox cbZona;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cbCliente;
        private System.Windows.Forms.CheckBox ckbEsSobrante;
        private System.Windows.Forms.ComboBox cbProducto;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblSimboloMoneda;
        private System.Windows.Forms.TextBox txtObservacionesVenta;
        private System.Windows.Forms.DataGridView dgvLineaVenta;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label lblTotalPesoNeto;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label lblTotalPesoTara;
        private System.Windows.Forms.Label lblTotalPesoBruto;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label lblMonto;
        private System.Windows.Forms.Button btnAceptarVenta;
        private System.Windows.Forms.DataGridView dgvListaVenta;
        private System.Windows.Forms.ComboBox cbVenta;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtNroDocumento;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.ComboBox cbTipoDocumento;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.ComboBox cbEmpresa;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.NumericUpDown nudPredio;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn14;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn15;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn16;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn17;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn18;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn19;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn20;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn21;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn22;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cbClienteB;
        private System.Windows.Forms.ComboBox cbProductoB;
        private System.Windows.Forms.ComboBox cbZonaB;
        private System.Windows.Forms.Button btnBuscar;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.DateTimePicker dtpFechaCaja;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn23;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.DataGridView dgvGastos;
        private System.Windows.Forms.BindingSource bdsGasto;
        private System.Windows.Forms.Button btnAceptarGasto;
        private System.Windows.Forms.BindingSource bdsTipoGasto;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn24;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn25;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn26;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn27;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn28;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn29;
        private System.Windows.Forms.DataGridViewTextBoxColumn dglColumn00;
        private System.Windows.Forms.DataGridViewTextBoxColumn dglColumn01;
        private System.Windows.Forms.DataGridViewTextBoxColumn dglColumn02;
        private System.Windows.Forms.DataGridViewTextBoxColumn dglColumn03;
        private System.Windows.Forms.DataGridViewTextBoxColumn dglColumn04;
        private System.Windows.Forms.DataGridViewTextBoxColumn dglColumn05;
        private System.Windows.Forms.DataGridViewTextBoxColumn dglColumn07;
        private System.Windows.Forms.DataGridViewTextBoxColumn dglColumn06;
        private System.Windows.Forms.DataGridViewTextBoxColumn dglColumn08;
        private System.Windows.Forms.DataGridViewTextBoxColumn dglColumn09;
        private System.Windows.Forms.DataGridViewTextBoxColumn dglColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dglColumn14;
        private System.Windows.Forms.DataGridViewTextBoxColumn dglColumn12;
        private System.Windows.Forms.DataGridViewTextBoxColumn dglColumn13;
        private System.Windows.Forms.DataGridViewButtonColumn verCuenta;
        private System.Windows.Forms.DataGridViewButtonColumn dglColumn11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.NumericUpDown nudCantidad;
        private System.Windows.Forms.CheckBox chkbAlContado;
        private System.Windows.Forms.NumericUpDown nudAmortizacion;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column00;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column02;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column01;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column03;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column04;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column05;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column06;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column07;
        private System.Windows.Forms.DataGridViewTextBoxColumn CantidadPollos;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column08;
        private System.Windows.Forms.DataGridViewButtonColumn Column09;
        private System.Windows.Forms.BindingSource bdsGasto2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn30;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn31;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn32;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn33;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn34;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn35;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn36;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn37;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label lblAnteriores;
        private System.Windows.Forms.Label lblCongelados;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lblMontoDia;
        private System.Windows.Forms.NumericUpDown NudGastoMonto;
        private System.Windows.Forms.TextBox txtGastoObservacion;
        private System.Windows.Forms.ComboBox cmbTipoGasto;
        private System.Windows.Forms.TextBox txtGastoConcepto;
        private System.Windows.Forms.DataGridViewComboBoxColumn idtipoGastoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn idgastoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn conceptoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn montoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn observacionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewButtonColumn grvGastoEliminar;
    }
}