using System;
using System.Collections.Generic;
using System.Text;

namespace DGP.Presentation.Ventas
{
    class Class1
    {
    }
}
