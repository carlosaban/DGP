﻿namespace DGP.Presentation.Ventas {

    partial class frmDetalleVenta {
        /// <summary>
        /// Variable del diseñador requerida.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén utilizando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben eliminar; false en caso contrario, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido del método con el editor de código.
        /// </summary>
        private void InitializeComponent() {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle54 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle65 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle55 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle56 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle57 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle58 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle59 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle60 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle61 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle62 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle63 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle64 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle66 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle67 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle69 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle68 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle70 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle77 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle71 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle72 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle73 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle74 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle75 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle76 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle78 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle79 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle80 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle81 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle82 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle83 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle84 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle85 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle86 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle87 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle88 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle89 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle90 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle91 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle92 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle93 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle94 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle95 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle96 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle97 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle98 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle99 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle100 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle101 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle102 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle103 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle104 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle105 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle106 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tcVenta = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.dgrvLineaVentaDS = new System.Windows.Forms.DataGridView();
            this.dsColumn01 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dsColumn02 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dsColumn03 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dsColumn04 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dsColumn05 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dsColumn06 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dsColumn07 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dsColumn08 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dsColumn09 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dsColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Unidades = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dsColumn11 = new System.Windows.Forms.DataGridViewButtonColumn();
            this.btnAceptarLineaVenta = new System.Windows.Forms.Button();
            this.btnRestablecerLineaVenta = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label7 = new System.Windows.Forms.Label();
            this.nudPrecioAmortizacion = new System.Windows.Forms.NumericUpDown();
            this.lblSimboloMonedaAM = new System.Windows.Forms.Label();
            this.btnAplicarMonto = new System.Windows.Forms.Button();
            this.btnAceptarAmortizacionVenta = new System.Windows.Forms.Button();
            this.dgrvAmortizacion = new System.Windows.Forms.DataGridView();
            this.dcaColumn00 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dcaColumn01 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dcaColumn02 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dcaColumn03 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dcaColumn04 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dcaColumn05 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dcaColumn06 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dcaColumn07 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dcaColumn08 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dcaColumn09 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dcaColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.dgrvDevolucion = new System.Windows.Forms.DataGridView();
            this.dcdColumn00 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dcdColumn01 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dcdColumn02 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dcdColumn03 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dcdColumn04 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dcdColumn05 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dcdColumn06 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dcdColumn07 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dcdColumn08 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dcdColumn09 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.UnidadesDesc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dcdColumn10 = new System.Windows.Forms.DataGridViewButtonColumn();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lblTotalNetoD = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.lblTotalTaraD = new System.Windows.Forms.Label();
            this.lblTotalBrutoD = new System.Windows.Forms.Label();
            this.btnAceptarDevolucionVenta = new System.Windows.Forms.Button();
            this.dataGridViewButtonColumn1 = new System.Windows.Forms.DataGridViewButtonColumn();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.nudPrecioVenta = new System.Windows.Forms.NumericUpDown();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.lblUnidades = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.lblDevoluciones = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.lblImporte = new System.Windows.Forms.Label();
            this.lblCabTotalNeto = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.lblCabTotalTara = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.lblCabTotalBruto = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.cbEstadoVentaG = new System.Windows.Forms.ComboBox();
            this.btnCancelarVenta = new System.Windows.Forms.Button();
            this.txtObservaciones = new System.Windows.Forms.TextBox();
            this.lblEmpresaVenta = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lblSimboloMoneda = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblProductoVenta = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lblClienteVenta = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblIDVenta = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn17 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn18 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn19 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn20 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn21 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn22 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn23 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn24 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn25 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn26 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn27 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn28 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn29 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn30 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn31 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn32 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn33 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn34 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn35 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn36 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn37 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn38 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn39 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn40 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tcVenta.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgrvLineaVentaDS)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudPrecioAmortizacion)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgrvAmortizacion)).BeginInit();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgrvDevolucion)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudPrecioVenta)).BeginInit();
            this.groupBox5.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // tcVenta
            // 
            this.tcVenta.Controls.Add(this.tabPage1);
            this.tcVenta.Controls.Add(this.tabPage2);
            this.tcVenta.Controls.Add(this.tabPage3);
            this.tcVenta.Location = new System.Drawing.Point(12, 184);
            this.tcVenta.Margin = new System.Windows.Forms.Padding(4);
            this.tcVenta.Name = "tcVenta";
            this.tcVenta.SelectedIndex = 0;
            this.tcVenta.Size = new System.Drawing.Size(911, 347);
            this.tcVenta.TabIndex = 0;
            this.tcVenta.SelectedIndexChanged += new System.EventHandler(this.tcVenta_SelectedIndexChanged);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.dgrvLineaVentaDS);
            this.tabPage1.Controls.Add(this.btnAceptarLineaVenta);
            this.tabPage1.Controls.Add(this.btnRestablecerLineaVenta);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage1.Size = new System.Drawing.Size(903, 318);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Lineas de Venta";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // dgrvLineaVentaDS
            // 
            this.dgrvLineaVentaDS.AllowUserToDeleteRows = false;
            this.dgrvLineaVentaDS.AllowUserToResizeColumns = false;
            this.dgrvLineaVentaDS.AllowUserToResizeRows = false;
            dataGridViewCellStyle54.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle54.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle54.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            dataGridViewCellStyle54.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle54.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle54.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle54.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgrvLineaVentaDS.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle54;
            this.dgrvLineaVentaDS.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgrvLineaVentaDS.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dsColumn01,
            this.dsColumn02,
            this.dsColumn03,
            this.dsColumn04,
            this.dsColumn05,
            this.dsColumn06,
            this.dsColumn07,
            this.dsColumn08,
            this.dsColumn09,
            this.dsColumn10,
            this.Unidades,
            this.dsColumn11});
            this.dgrvLineaVentaDS.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.dgrvLineaVentaDS.Location = new System.Drawing.Point(9, 9);
            this.dgrvLineaVentaDS.MultiSelect = false;
            this.dgrvLineaVentaDS.Name = "dgrvLineaVentaDS";
            dataGridViewCellStyle65.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle65.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle65.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            dataGridViewCellStyle65.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle65.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle65.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle65.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgrvLineaVentaDS.RowHeadersDefaultCellStyle = dataGridViewCellStyle65;
            this.dgrvLineaVentaDS.RowHeadersWidth = 25;
            this.dgrvLineaVentaDS.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgrvLineaVentaDS.Size = new System.Drawing.Size(779, 318);
            this.dgrvLineaVentaDS.StandardTab = true;
            this.dgrvLineaVentaDS.TabIndex = 15;
            this.dgrvLineaVentaDS.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgrvLineaVentaDS_CellMouseClick);
            this.dgrvLineaVentaDS.CellBeginEdit += new System.Windows.Forms.DataGridViewCellCancelEventHandler(this.dgrvLineaVentaDS_CellBeginEdit);
            this.dgrvLineaVentaDS.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgrvLineaVentaDS_CellEndEdit);
            this.dgrvLineaVentaDS.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtTABToENTER_KeyPress);
            this.dgrvLineaVentaDS.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgrvLineaVentaDS_CellContentClick);
            // 
            // dsColumn01
            // 
            this.dsColumn01.DataPropertyName = "IdLineaVenta";
            dataGridViewCellStyle55.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dsColumn01.DefaultCellStyle = dataGridViewCellStyle55;
            this.dsColumn01.Frozen = true;
            this.dsColumn01.HeaderText = "Id";
            this.dsColumn01.Name = "dsColumn01";
            this.dsColumn01.ReadOnly = true;
            this.dsColumn01.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dsColumn01.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dsColumn01.Visible = false;
            this.dsColumn01.Width = 50;
            // 
            // dsColumn02
            // 
            this.dsColumn02.DataPropertyName = "FlagJava";
            dataGridViewCellStyle56.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dsColumn02.DefaultCellStyle = dataGridViewCellStyle56;
            this.dsColumn02.Frozen = true;
            this.dsColumn02.HeaderText = "Flag Java";
            this.dsColumn02.Name = "dsColumn02";
            this.dsColumn02.ReadOnly = true;
            this.dsColumn02.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dsColumn02.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dsColumn02.Visible = false;
            this.dsColumn02.Width = 40;
            // 
            // dsColumn03
            // 
            this.dsColumn03.DataPropertyName = "TaraEditada";
            dataGridViewCellStyle57.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dsColumn03.DefaultCellStyle = dataGridViewCellStyle57;
            this.dsColumn03.Frozen = true;
            this.dsColumn03.HeaderText = "Tara Editada";
            this.dsColumn03.Name = "dsColumn03";
            this.dsColumn03.ReadOnly = true;
            this.dsColumn03.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dsColumn03.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dsColumn03.Visible = false;
            this.dsColumn03.Width = 60;
            // 
            // dsColumn04
            // 
            this.dsColumn04.DataPropertyName = "EsPesoTaraEditado";
            dataGridViewCellStyle58.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dsColumn04.DefaultCellStyle = dataGridViewCellStyle58;
            this.dsColumn04.Frozen = true;
            this.dsColumn04.HeaderText = "Flag Peso Tara";
            this.dsColumn04.Name = "dsColumn04";
            this.dsColumn04.ReadOnly = true;
            this.dsColumn04.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dsColumn04.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dsColumn04.Visible = false;
            this.dsColumn04.Width = 50;
            // 
            // dsColumn05
            // 
            this.dsColumn05.DataPropertyName = "CantidadJavas";
            dataGridViewCellStyle59.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dsColumn05.DefaultCellStyle = dataGridViewCellStyle59;
            this.dsColumn05.Frozen = true;
            this.dsColumn05.HeaderText = "Cantidad Javas";
            this.dsColumn05.Name = "dsColumn05";
            this.dsColumn05.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dsColumn05.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dsColumn05.Width = 70;
            // 
            // dsColumn06
            // 
            this.dsColumn06.DataPropertyName = "PesoJava";
            dataGridViewCellStyle60.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dsColumn06.DefaultCellStyle = dataGridViewCellStyle60;
            this.dsColumn06.Frozen = true;
            this.dsColumn06.HeaderText = "Peso Javas";
            this.dsColumn06.Name = "dsColumn06";
            this.dsColumn06.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dsColumn06.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dsColumn06.Width = 70;
            // 
            // dsColumn07
            // 
            this.dsColumn07.DataPropertyName = "PesoBruto";
            dataGridViewCellStyle61.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dsColumn07.DefaultCellStyle = dataGridViewCellStyle61;
            this.dsColumn07.Frozen = true;
            this.dsColumn07.HeaderText = "Peso Bruto";
            this.dsColumn07.Name = "dsColumn07";
            this.dsColumn07.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dsColumn07.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dsColumn07.Width = 70;
            // 
            // dsColumn08
            // 
            this.dsColumn08.DataPropertyName = "PesoTara";
            dataGridViewCellStyle62.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dsColumn08.DefaultCellStyle = dataGridViewCellStyle62;
            this.dsColumn08.Frozen = true;
            this.dsColumn08.HeaderText = "Peso Tara";
            this.dsColumn08.Name = "dsColumn08";
            this.dsColumn08.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dsColumn08.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dsColumn08.Width = 70;
            // 
            // dsColumn09
            // 
            this.dsColumn09.DataPropertyName = "PesoNeto";
            dataGridViewCellStyle63.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dsColumn09.DefaultCellStyle = dataGridViewCellStyle63;
            this.dsColumn09.Frozen = true;
            this.dsColumn09.HeaderText = "Peso Neto";
            this.dsColumn09.Name = "dsColumn09";
            this.dsColumn09.ReadOnly = true;
            this.dsColumn09.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dsColumn09.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dsColumn09.Width = 70;
            // 
            // dsColumn10
            // 
            this.dsColumn10.DataPropertyName = "Observacion";
            dataGridViewCellStyle64.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dsColumn10.DefaultCellStyle = dataGridViewCellStyle64;
            this.dsColumn10.Frozen = true;
            this.dsColumn10.HeaderText = "Observación";
            this.dsColumn10.Name = "dsColumn10";
            this.dsColumn10.ReadOnly = true;
            this.dsColumn10.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dsColumn10.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dsColumn10.Width = 220;
            // 
            // Unidades
            // 
            this.Unidades.DataPropertyName = "Unidades";
            this.Unidades.Frozen = true;
            this.Unidades.HeaderText = "Unidades";
            this.Unidades.Name = "Unidades";
            // 
            // dsColumn11
            // 
            this.dsColumn11.HeaderText = "Acción";
            this.dsColumn11.Name = "dsColumn11";
            this.dsColumn11.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dsColumn11.Text = "Eliminar";
            this.dsColumn11.UseColumnTextForButtonValue = true;
            // 
            // btnAceptarLineaVenta
            // 
            this.btnAceptarLineaVenta.Location = new System.Drawing.Point(794, 288);
            this.btnAceptarLineaVenta.Name = "btnAceptarLineaVenta";
            this.btnAceptarLineaVenta.Size = new System.Drawing.Size(89, 23);
            this.btnAceptarLineaVenta.TabIndex = 14;
            this.btnAceptarLineaVenta.Text = "Aceptar";
            this.btnAceptarLineaVenta.UseVisualStyleBackColor = true;
            this.btnAceptarLineaVenta.Click += new System.EventHandler(this.btnAceptarLineaVenta_Click);
            // 
            // btnRestablecerLineaVenta
            // 
            this.btnRestablecerLineaVenta.Location = new System.Drawing.Point(794, 9);
            this.btnRestablecerLineaVenta.Name = "btnRestablecerLineaVenta";
            this.btnRestablecerLineaVenta.Size = new System.Drawing.Size(85, 25);
            this.btnRestablecerLineaVenta.TabIndex = 13;
            this.btnRestablecerLineaVenta.Text = "Restablecer";
            this.btnRestablecerLineaVenta.UseVisualStyleBackColor = true;
            this.btnRestablecerLineaVenta.Click += new System.EventHandler(this.btnRestablecerLineaVenta_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.groupBox4);
            this.tabPage2.Controls.Add(this.btnAceptarAmortizacionVenta);
            this.tabPage2.Controls.Add(this.dgrvAmortizacion);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage2.Size = new System.Drawing.Size(903, 318);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Amortización de Venta";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.label7);
            this.groupBox4.Controls.Add(this.nudPrecioAmortizacion);
            this.groupBox4.Controls.Add(this.lblSimboloMonedaAM);
            this.groupBox4.Controls.Add(this.btnAplicarMonto);
            this.groupBox4.Location = new System.Drawing.Point(740, 7);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(156, 100);
            this.groupBox4.TabIndex = 16;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Monto";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(14, 18);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(48, 16);
            this.label7.TabIndex = 11;
            this.label7.Text = "Pagar:";
            // 
            // nudPrecioAmortizacion
            // 
            this.nudPrecioAmortizacion.DecimalPlaces = 2;
            this.nudPrecioAmortizacion.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nudPrecioAmortizacion.Location = new System.Drawing.Point(47, 38);
            this.nudPrecioAmortizacion.Margin = new System.Windows.Forms.Padding(4);
            this.nudPrecioAmortizacion.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.nudPrecioAmortizacion.Name = "nudPrecioAmortizacion";
            this.nudPrecioAmortizacion.Size = new System.Drawing.Size(93, 22);
            this.nudPrecioAmortizacion.TabIndex = 13;
            this.nudPrecioAmortizacion.ThousandsSeparator = true;
            this.nudPrecioAmortizacion.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // lblSimboloMonedaAM
            // 
            this.lblSimboloMonedaAM.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.lblSimboloMonedaAM.Location = new System.Drawing.Point(16, 40);
            this.lblSimboloMonedaAM.Name = "lblSimboloMonedaAM";
            this.lblSimboloMonedaAM.Size = new System.Drawing.Size(24, 15);
            this.lblSimboloMonedaAM.TabIndex = 14;
            // 
            // btnAplicarMonto
            // 
            this.btnAplicarMonto.Location = new System.Drawing.Point(17, 67);
            this.btnAplicarMonto.Name = "btnAplicarMonto";
            this.btnAplicarMonto.Size = new System.Drawing.Size(123, 23);
            this.btnAplicarMonto.TabIndex = 12;
            this.btnAplicarMonto.Text = "Aplicar";
            this.btnAplicarMonto.UseVisualStyleBackColor = true;
            this.btnAplicarMonto.Click += new System.EventHandler(this.btnAplicarMonto_Click);
            // 
            // btnAceptarAmortizacionVenta
            // 
            this.btnAceptarAmortizacionVenta.Location = new System.Drawing.Point(757, 288);
            this.btnAceptarAmortizacionVenta.Name = "btnAceptarAmortizacionVenta";
            this.btnAceptarAmortizacionVenta.Size = new System.Drawing.Size(123, 23);
            this.btnAceptarAmortizacionVenta.TabIndex = 15;
            this.btnAceptarAmortizacionVenta.Text = "Aceptar";
            this.btnAceptarAmortizacionVenta.UseVisualStyleBackColor = true;
            this.btnAceptarAmortizacionVenta.Click += new System.EventHandler(this.btnAceptarAmortizacionVenta_Click);
            // 
            // dgrvAmortizacion
            // 
            this.dgrvAmortizacion.AllowUserToAddRows = false;
            this.dgrvAmortizacion.AllowUserToDeleteRows = false;
            dataGridViewCellStyle66.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle66.Format = "N2";
            dataGridViewCellStyle66.NullValue = null;
            dataGridViewCellStyle66.SelectionBackColor = System.Drawing.Color.White;
            dataGridViewCellStyle66.SelectionForeColor = System.Drawing.Color.Black;
            this.dgrvAmortizacion.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle66;
            dataGridViewCellStyle67.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle67.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle67.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            dataGridViewCellStyle67.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle67.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle67.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle67.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgrvAmortizacion.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle67;
            this.dgrvAmortizacion.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgrvAmortizacion.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dcaColumn00,
            this.dcaColumn01,
            this.dcaColumn02,
            this.dcaColumn03,
            this.dcaColumn04,
            this.dcaColumn05,
            this.dcaColumn06,
            this.dcaColumn07,
            this.dcaColumn08,
            this.dcaColumn09,
            this.dcaColumn10});
            this.dgrvAmortizacion.Location = new System.Drawing.Point(9, 9);
            this.dgrvAmortizacion.MultiSelect = false;
            this.dgrvAmortizacion.Name = "dgrvAmortizacion";
            this.dgrvAmortizacion.RowHeadersVisible = false;
            this.dgrvAmortizacion.RowHeadersWidth = 20;
            dataGridViewCellStyle69.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle69.SelectionBackColor = System.Drawing.Color.White;
            dataGridViewCellStyle69.SelectionForeColor = System.Drawing.Color.Black;
            this.dgrvAmortizacion.RowsDefaultCellStyle = dataGridViewCellStyle69;
            this.dgrvAmortizacion.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgrvAmortizacion.Size = new System.Drawing.Size(727, 314);
            this.dgrvAmortizacion.StandardTab = true;
            this.dgrvAmortizacion.TabIndex = 2;
            this.dgrvAmortizacion.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgrvAmortizacion_CellEndEdit);
            // 
            // dcaColumn00
            // 
            this.dcaColumn00.DataPropertyName = "Indicador";
            this.dcaColumn00.Frozen = true;
            this.dcaColumn00.HeaderText = "Indicador";
            this.dcaColumn00.Name = "dcaColumn00";
            this.dcaColumn00.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dcaColumn00.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dcaColumn00.Visible = false;
            this.dcaColumn00.Width = 50;
            // 
            // dcaColumn01
            // 
            this.dcaColumn01.DataPropertyName = "IdVenta";
            this.dcaColumn01.Frozen = true;
            this.dcaColumn01.HeaderText = "IdVenta";
            this.dcaColumn01.Name = "dcaColumn01";
            this.dcaColumn01.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dcaColumn01.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dcaColumn01.Visible = false;
            this.dcaColumn01.Width = 70;
            // 
            // dcaColumn02
            // 
            this.dcaColumn02.DataPropertyName = "IdProducto";
            this.dcaColumn02.Frozen = true;
            this.dcaColumn02.HeaderText = "IdProducto";
            this.dcaColumn02.Name = "dcaColumn02";
            this.dcaColumn02.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dcaColumn02.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dcaColumn02.Visible = false;
            this.dcaColumn02.Width = 70;
            // 
            // dcaColumn03
            // 
            this.dcaColumn03.DataPropertyName = "TipoDocumento";
            this.dcaColumn03.Frozen = true;
            this.dcaColumn03.HeaderText = "Tipo Documento";
            this.dcaColumn03.MaxInputLength = 1;
            this.dcaColumn03.Name = "dcaColumn03";
            this.dcaColumn03.ReadOnly = true;
            this.dcaColumn03.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dcaColumn03.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dcaColumn03.Visible = false;
            this.dcaColumn03.Width = 150;
            // 
            // dcaColumn04
            // 
            this.dcaColumn04.DataPropertyName = "Producto";
            this.dcaColumn04.HeaderText = "Producto";
            this.dcaColumn04.Name = "dcaColumn04";
            this.dcaColumn04.ReadOnly = true;
            this.dcaColumn04.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dcaColumn04.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dcaColumn04.Width = 200;
            // 
            // dcaColumn05
            // 
            this.dcaColumn05.DataPropertyName = "Fecha";
            dataGridViewCellStyle68.Format = "d";
            dataGridViewCellStyle68.NullValue = null;
            this.dcaColumn05.DefaultCellStyle = dataGridViewCellStyle68;
            this.dcaColumn05.HeaderText = "Fecha";
            this.dcaColumn05.Name = "dcaColumn05";
            this.dcaColumn05.ReadOnly = true;
            this.dcaColumn05.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dcaColumn05.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dcaColumn05.Width = 80;
            // 
            // dcaColumn06
            // 
            this.dcaColumn06.DataPropertyName = "strCantidadJavas";
            this.dcaColumn06.HeaderText = "Cantidad Javas";
            this.dcaColumn06.Name = "dcaColumn06";
            this.dcaColumn06.ReadOnly = true;
            this.dcaColumn06.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dcaColumn06.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dcaColumn06.Width = 80;
            // 
            // dcaColumn07
            // 
            this.dcaColumn07.DataPropertyName = "strPesoNeto";
            this.dcaColumn07.HeaderText = "Peso Neto";
            this.dcaColumn07.Name = "dcaColumn07";
            this.dcaColumn07.ReadOnly = true;
            this.dcaColumn07.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dcaColumn07.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dcaColumn07.Width = 80;
            // 
            // dcaColumn08
            // 
            this.dcaColumn08.DataPropertyName = "Importe";
            this.dcaColumn08.HeaderText = "Importe";
            this.dcaColumn08.Name = "dcaColumn08";
            this.dcaColumn08.ReadOnly = true;
            this.dcaColumn08.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dcaColumn08.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dcaColumn08.Width = 90;
            // 
            // dcaColumn09
            // 
            this.dcaColumn09.DataPropertyName = "strSaldo";
            this.dcaColumn09.HeaderText = "Saldo";
            this.dcaColumn09.Name = "dcaColumn09";
            this.dcaColumn09.ReadOnly = true;
            this.dcaColumn09.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dcaColumn09.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dcaColumn09.Width = 90;
            // 
            // dcaColumn10
            // 
            this.dcaColumn10.HeaderText = "Pago a Cuenta";
            this.dcaColumn10.Name = "dcaColumn10";
            this.dcaColumn10.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dcaColumn10.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dcaColumn10.Width = 90;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.dgrvDevolucion);
            this.tabPage3.Controls.Add(this.groupBox3);
            this.tabPage3.Controls.Add(this.btnAceptarDevolucionVenta);
            this.tabPage3.Location = new System.Drawing.Point(4, 25);
            this.tabPage3.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(903, 318);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Devolución de Venta";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // dgrvDevolucion
            // 
            this.dgrvDevolucion.AllowUserToDeleteRows = false;
            this.dgrvDevolucion.AllowUserToResizeColumns = false;
            this.dgrvDevolucion.AllowUserToResizeRows = false;
            dataGridViewCellStyle70.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle70.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle70.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            dataGridViewCellStyle70.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle70.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle70.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle70.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgrvDevolucion.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle70;
            this.dgrvDevolucion.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgrvDevolucion.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dcdColumn00,
            this.dcdColumn01,
            this.dcdColumn02,
            this.dcdColumn03,
            this.dcdColumn04,
            this.dcdColumn05,
            this.dcdColumn06,
            this.dcdColumn07,
            this.dcdColumn08,
            this.dcdColumn09,
            this.UnidadesDesc,
            this.dcdColumn10});
            this.dgrvDevolucion.Location = new System.Drawing.Point(9, 9);
            this.dgrvDevolucion.Margin = new System.Windows.Forms.Padding(5);
            this.dgrvDevolucion.MultiSelect = false;
            this.dgrvDevolucion.Name = "dgrvDevolucion";
            this.dgrvDevolucion.RowHeadersWidth = 25;
            this.dgrvDevolucion.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dataGridViewCellStyle77.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgrvDevolucion.RowsDefaultCellStyle = dataGridViewCellStyle77;
            this.dgrvDevolucion.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgrvDevolucion.Size = new System.Drawing.Size(700, 312);
            this.dgrvDevolucion.StandardTab = true;
            this.dgrvDevolucion.TabIndex = 16;
            this.dgrvDevolucion.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgrvDevolucion_CellMouseClick);
            this.dgrvDevolucion.CellBeginEdit += new System.Windows.Forms.DataGridViewCellCancelEventHandler(this.dgrvDevolucion_CellBeginEdit);
            this.dgrvDevolucion.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgrvDevolucion_CellEndEdit);
            this.dgrvDevolucion.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgrvDevolucion_CellContentClick);
            // 
            // dcdColumn00
            // 
            this.dcdColumn00.DataPropertyName = "IdLineaVenta";
            this.dcdColumn00.HeaderText = "Id";
            this.dcdColumn00.Name = "dcdColumn00";
            this.dcdColumn00.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dcdColumn00.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dcdColumn00.Visible = false;
            this.dcdColumn00.Width = 65;
            // 
            // dcdColumn01
            // 
            this.dcdColumn01.DataPropertyName = "FlagJava";
            this.dcdColumn01.HeaderText = "FlagJava";
            this.dcdColumn01.Name = "dcdColumn01";
            this.dcdColumn01.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dcdColumn01.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dcdColumn01.Visible = false;
            this.dcdColumn01.Width = 65;
            // 
            // dcdColumn02
            // 
            this.dcdColumn02.DataPropertyName = "TaraEditada";
            this.dcdColumn02.HeaderText = "TaraCalculado";
            this.dcdColumn02.MaxInputLength = 11;
            this.dcdColumn02.Name = "dcdColumn02";
            this.dcdColumn02.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dcdColumn02.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dcdColumn02.Visible = false;
            this.dcdColumn02.Width = 130;
            // 
            // dcdColumn03
            // 
            this.dcdColumn03.DataPropertyName = "EsPesoTaraEditado";
            this.dcdColumn03.HeaderText = "FlagPesoTara";
            this.dcdColumn03.Name = "dcdColumn03";
            this.dcdColumn03.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dcdColumn03.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dcdColumn03.Visible = false;
            this.dcdColumn03.Width = 95;
            // 
            // dcdColumn04
            // 
            this.dcdColumn04.DataPropertyName = "CantidadJavas";
            dataGridViewCellStyle71.Format = "N0";
            dataGridViewCellStyle71.NullValue = null;
            this.dcdColumn04.DefaultCellStyle = dataGridViewCellStyle71;
            this.dcdColumn04.HeaderText = "Cantidad Javas";
            this.dcdColumn04.MaxInputLength = 4;
            this.dcdColumn04.Name = "dcdColumn04";
            this.dcdColumn04.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dcdColumn04.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dcdColumn04.Width = 70;
            // 
            // dcdColumn05
            // 
            this.dcdColumn05.DataPropertyName = "PesoJava";
            dataGridViewCellStyle72.Format = "N2";
            dataGridViewCellStyle72.NullValue = null;
            this.dcdColumn05.DefaultCellStyle = dataGridViewCellStyle72;
            this.dcdColumn05.HeaderText = "Peso Javas";
            this.dcdColumn05.MaxInputLength = 11;
            this.dcdColumn05.Name = "dcdColumn05";
            this.dcdColumn05.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dcdColumn05.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dcdColumn05.Width = 70;
            // 
            // dcdColumn06
            // 
            this.dcdColumn06.DataPropertyName = "PesoBruto";
            dataGridViewCellStyle73.Format = "N2";
            dataGridViewCellStyle73.NullValue = null;
            this.dcdColumn06.DefaultCellStyle = dataGridViewCellStyle73;
            this.dcdColumn06.HeaderText = "Peso Bruto";
            this.dcdColumn06.MaxInputLength = 11;
            this.dcdColumn06.Name = "dcdColumn06";
            this.dcdColumn06.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dcdColumn06.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dcdColumn06.Width = 70;
            // 
            // dcdColumn07
            // 
            this.dcdColumn07.DataPropertyName = "PesoTara";
            dataGridViewCellStyle74.Format = "N2";
            dataGridViewCellStyle74.NullValue = null;
            this.dcdColumn07.DefaultCellStyle = dataGridViewCellStyle74;
            this.dcdColumn07.HeaderText = "Peso Tara";
            this.dcdColumn07.MaxInputLength = 11;
            this.dcdColumn07.Name = "dcdColumn07";
            this.dcdColumn07.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dcdColumn07.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dcdColumn07.Width = 70;
            // 
            // dcdColumn08
            // 
            this.dcdColumn08.DataPropertyName = "PesoNeto";
            dataGridViewCellStyle75.Format = "N2";
            dataGridViewCellStyle75.NullValue = null;
            this.dcdColumn08.DefaultCellStyle = dataGridViewCellStyle75;
            this.dcdColumn08.HeaderText = "Peso Neto";
            this.dcdColumn08.MaxInputLength = 11;
            this.dcdColumn08.Name = "dcdColumn08";
            this.dcdColumn08.ReadOnly = true;
            this.dcdColumn08.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dcdColumn08.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dcdColumn08.Width = 70;
            // 
            // dcdColumn09
            // 
            this.dcdColumn09.DataPropertyName = "Observacion";
            this.dcdColumn09.HeaderText = "Observación";
            this.dcdColumn09.MaxInputLength = 200;
            this.dcdColumn09.Name = "dcdColumn09";
            this.dcdColumn09.ReadOnly = true;
            this.dcdColumn09.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dcdColumn09.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dcdColumn09.Width = 200;
            // 
            // UnidadesDesc
            // 
            this.UnidadesDesc.DataPropertyName = "Unidades";
            this.UnidadesDesc.HeaderText = "Unidades";
            this.UnidadesDesc.Name = "UnidadesDesc";
            // 
            // dcdColumn10
            // 
            dataGridViewCellStyle76.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle76.BackColor = System.Drawing.Color.WhiteSmoke;
            dataGridViewCellStyle76.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle76.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle76.SelectionBackColor = System.Drawing.Color.Gray;
            this.dcdColumn10.DefaultCellStyle = dataGridViewCellStyle76;
            this.dcdColumn10.HeaderText = "Acción";
            this.dcdColumn10.Name = "dcdColumn10";
            this.dcdColumn10.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dcdColumn10.Text = "Eliminar";
            this.dcdColumn10.UseColumnTextForButtonValue = true;
            this.dcdColumn10.Width = 70;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label9);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.lblTotalNetoD);
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Controls.Add(this.lblTotalTaraD);
            this.groupBox3.Controls.Add(this.lblTotalBrutoD);
            this.groupBox3.Location = new System.Drawing.Point(715, 7);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(180, 130);
            this.groupBox3.TabIndex = 15;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Detalle Devolución";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(4, 26);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(76, 16);
            this.label9.TabIndex = 14;
            this.label9.Text = "Total Bruto:";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(4, 60);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(74, 16);
            this.label6.TabIndex = 12;
            this.label6.Text = "Total Tara:";
            // 
            // lblTotalNetoD
            // 
            this.lblTotalNetoD.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblTotalNetoD.Location = new System.Drawing.Point(80, 93);
            this.lblTotalNetoD.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTotalNetoD.Name = "lblTotalNetoD";
            this.lblTotalNetoD.Size = new System.Drawing.Size(93, 25);
            this.lblTotalNetoD.TabIndex = 6;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(4, 94);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(74, 16);
            this.label8.TabIndex = 5;
            this.label8.Text = "Total Neto:";
            // 
            // lblTotalTaraD
            // 
            this.lblTotalTaraD.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblTotalTaraD.Location = new System.Drawing.Point(80, 25);
            this.lblTotalTaraD.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTotalTaraD.Name = "lblTotalTaraD";
            this.lblTotalTaraD.Size = new System.Drawing.Size(93, 25);
            this.lblTotalTaraD.TabIndex = 13;
            // 
            // lblTotalBrutoD
            // 
            this.lblTotalBrutoD.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblTotalBrutoD.Location = new System.Drawing.Point(80, 59);
            this.lblTotalBrutoD.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTotalBrutoD.Name = "lblTotalBrutoD";
            this.lblTotalBrutoD.Size = new System.Drawing.Size(93, 25);
            this.lblTotalBrutoD.TabIndex = 11;
            // 
            // btnAceptarDevolucionVenta
            // 
            this.btnAceptarDevolucionVenta.Location = new System.Drawing.Point(722, 287);
            this.btnAceptarDevolucionVenta.Name = "btnAceptarDevolucionVenta";
            this.btnAceptarDevolucionVenta.Size = new System.Drawing.Size(166, 23);
            this.btnAceptarDevolucionVenta.TabIndex = 14;
            this.btnAceptarDevolucionVenta.Text = "Aceptar";
            this.btnAceptarDevolucionVenta.UseVisualStyleBackColor = true;
            this.btnAceptarDevolucionVenta.Click += new System.EventHandler(this.btnAceptarDevolucionVenta_Click);
            // 
            // dataGridViewButtonColumn1
            // 
            dataGridViewCellStyle78.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle78.BackColor = System.Drawing.Color.WhiteSmoke;
            dataGridViewCellStyle78.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle78.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle78.SelectionBackColor = System.Drawing.Color.Gray;
            this.dataGridViewButtonColumn1.DefaultCellStyle = dataGridViewCellStyle78;
            this.dataGridViewButtonColumn1.HeaderText = "Acción";
            this.dataGridViewButtonColumn1.Name = "dataGridViewButtonColumn1";
            this.dataGridViewButtonColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewButtonColumn1.Text = "Eliminar";
            this.dataGridViewButtonColumn1.UseColumnTextForButtonValue = true;
            this.dataGridViewButtonColumn1.Width = 70;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.nudPrecioVenta);
            this.groupBox1.Controls.Add(this.groupBox5);
            this.groupBox1.Controls.Add(this.groupBox2);
            this.groupBox1.Controls.Add(this.lblEmpresaVenta);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.lblSimboloMoneda);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.lblProductoVenta);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.lblClienteVenta);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.lblIDVenta);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(5, 5);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(911, 171);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Venta";
            // 
            // nudPrecioVenta
            // 
            this.nudPrecioVenta.DecimalPlaces = 2;
            this.nudPrecioVenta.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.nudPrecioVenta.Increment = new decimal(new int[] {
            5,
            0,
            0,
            131072});
            this.nudPrecioVenta.Location = new System.Drawing.Point(427, 55);
            this.nudPrecioVenta.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.nudPrecioVenta.Name = "nudPrecioVenta";
            this.nudPrecioVenta.Size = new System.Drawing.Size(103, 22);
            this.nudPrecioVenta.TabIndex = 5;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.lblUnidades);
            this.groupBox5.Controls.Add(this.label13);
            this.groupBox5.Controls.Add(this.label14);
            this.groupBox5.Controls.Add(this.lblDevoluciones);
            this.groupBox5.Controls.Add(this.label11);
            this.groupBox5.Controls.Add(this.lblImporte);
            this.groupBox5.Controls.Add(this.lblCabTotalNeto);
            this.groupBox5.Controls.Add(this.label15);
            this.groupBox5.Controls.Add(this.label12);
            this.groupBox5.Controls.Add(this.lblCabTotalTara);
            this.groupBox5.Controls.Add(this.label10);
            this.groupBox5.Controls.Add(this.lblCabTotalBruto);
            this.groupBox5.Location = new System.Drawing.Point(7, 80);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(523, 74);
            this.groupBox5.TabIndex = 13;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Detalle";
            // 
            // lblUnidades
            // 
            this.lblUnidades.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblUnidades.Location = new System.Drawing.Point(79, 45);
            this.lblUnidades.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblUnidades.Name = "lblUnidades";
            this.lblUnidades.Size = new System.Drawing.Size(90, 20);
            this.lblUnidades.TabIndex = 26;
            this.lblUnidades.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(3, 49);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(70, 16);
            this.label13.TabIndex = 25;
            this.label13.Text = "Unidades:";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(200, 53);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(47, 16);
            this.label14.TabIndex = 24;
            this.label14.Text = "Devol:";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblDevoluciones
            // 
            this.lblDevoluciones.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblDevoluciones.Location = new System.Drawing.Point(247, 49);
            this.lblDevoluciones.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDevoluciones.Name = "lblDevoluciones";
            this.lblDevoluciones.Size = new System.Drawing.Size(90, 20);
            this.lblDevoluciones.TabIndex = 23;
            this.lblDevoluciones.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(354, 51);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(56, 16);
            this.label11.TabIndex = 22;
            this.label11.Text = "Importe:";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblImporte
            // 
            this.lblImporte.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblImporte.Location = new System.Drawing.Point(418, 51);
            this.lblImporte.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblImporte.Name = "lblImporte";
            this.lblImporte.Size = new System.Drawing.Size(90, 20);
            this.lblImporte.TabIndex = 21;
            this.lblImporte.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblCabTotalNeto
            // 
            this.lblCabTotalNeto.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblCabTotalNeto.Location = new System.Drawing.Point(418, 19);
            this.lblCabTotalNeto.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCabTotalNeto.Name = "lblCabTotalNeto";
            this.lblCabTotalNeto.Size = new System.Drawing.Size(90, 20);
            this.lblCabTotalNeto.TabIndex = 20;
            this.lblCabTotalNeto.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(342, 21);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(74, 16);
            this.label15.TabIndex = 19;
            this.label15.Text = "Total Neto:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(173, 21);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(74, 16);
            this.label12.TabIndex = 18;
            this.label12.Text = "Total Tara:";
            // 
            // lblCabTotalTara
            // 
            this.lblCabTotalTara.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblCabTotalTara.Location = new System.Drawing.Point(247, 19);
            this.lblCabTotalTara.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCabTotalTara.Name = "lblCabTotalTara";
            this.lblCabTotalTara.Size = new System.Drawing.Size(90, 20);
            this.lblCabTotalTara.TabIndex = 17;
            this.lblCabTotalTara.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(3, 21);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(76, 16);
            this.label10.TabIndex = 16;
            this.label10.Text = "Total Bruto:";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblCabTotalBruto
            // 
            this.lblCabTotalBruto.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblCabTotalBruto.Location = new System.Drawing.Point(79, 19);
            this.lblCabTotalBruto.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCabTotalBruto.Name = "lblCabTotalBruto";
            this.lblCabTotalBruto.Size = new System.Drawing.Size(90, 20);
            this.lblCabTotalBruto.TabIndex = 15;
            this.lblCabTotalBruto.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.cbEstadoVentaG);
            this.groupBox2.Controls.Add(this.btnCancelarVenta);
            this.groupBox2.Controls.Add(this.txtObservaciones);
            this.groupBox2.Location = new System.Drawing.Point(544, 9);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(360, 145);
            this.groupBox2.TabIndex = 12;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Estado";
            // 
            // cbEstadoVentaG
            // 
            this.cbEstadoVentaG.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbEstadoVentaG.FormattingEnabled = true;
            this.cbEstadoVentaG.Location = new System.Drawing.Point(8, 21);
            this.cbEstadoVentaG.Name = "cbEstadoVentaG";
            this.cbEstadoVentaG.Size = new System.Drawing.Size(129, 24);
            this.cbEstadoVentaG.TabIndex = 4;
            this.cbEstadoVentaG.SelectedIndexChanged += new System.EventHandler(this.cbEstadoVentaG_SelectedIndexChanged);
            // 
            // btnCancelarVenta
            // 
            this.btnCancelarVenta.Location = new System.Drawing.Point(18, 109);
            this.btnCancelarVenta.Name = "btnCancelarVenta";
            this.btnCancelarVenta.Size = new System.Drawing.Size(108, 29);
            this.btnCancelarVenta.TabIndex = 3;
            this.btnCancelarVenta.Text = "Registrar";
            this.btnCancelarVenta.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnCancelarVenta.UseVisualStyleBackColor = true;
            this.btnCancelarVenta.Click += new System.EventHandler(this.btnCancelarVenta_Click);
            // 
            // txtObservaciones
            // 
            this.txtObservaciones.Location = new System.Drawing.Point(143, 13);
            this.txtObservaciones.Multiline = true;
            this.txtObservaciones.Name = "txtObservaciones";
            this.txtObservaciones.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtObservaciones.Size = new System.Drawing.Size(207, 125);
            this.txtObservaciones.TabIndex = 1;
            // 
            // lblEmpresaVenta
            // 
            this.lblEmpresaVenta.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblEmpresaVenta.Location = new System.Drawing.Point(82, 55);
            this.lblEmpresaVenta.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblEmpresaVenta.Name = "lblEmpresaVenta";
            this.lblEmpresaVenta.Size = new System.Drawing.Size(264, 20);
            this.lblEmpresaVenta.TabIndex = 11;
            this.lblEmpresaVenta.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(8, 57);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(66, 16);
            this.label4.TabIndex = 10;
            this.label4.Text = "Empresa:";
            // 
            // lblSimboloMoneda
            // 
            this.lblSimboloMoneda.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.lblSimboloMoneda.Location = new System.Drawing.Point(658, 66);
            this.lblSimboloMoneda.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSimboloMoneda.Name = "lblSimboloMoneda";
            this.lblSimboloMoneda.Size = new System.Drawing.Size(55, 28);
            this.lblSimboloMoneda.TabIndex = 7;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(354, 55);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(50, 16);
            this.label2.TabIndex = 6;
            this.label2.Text = "Precio:";
            // 
            // lblProductoVenta
            // 
            this.lblProductoVenta.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblProductoVenta.Location = new System.Drawing.Point(427, 25);
            this.lblProductoVenta.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblProductoVenta.Name = "lblProductoVenta";
            this.lblProductoVenta.Size = new System.Drawing.Size(103, 20);
            this.lblProductoVenta.TabIndex = 5;
            this.lblProductoVenta.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(354, 27);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(65, 16);
            this.label5.TabIndex = 4;
            this.label5.Text = "Producto:";
            // 
            // lblClienteVenta
            // 
            this.lblClienteVenta.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblClienteVenta.Location = new System.Drawing.Point(171, 25);
            this.lblClienteVenta.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblClienteVenta.Name = "lblClienteVenta";
            this.lblClienteVenta.Size = new System.Drawing.Size(175, 20);
            this.lblClienteVenta.TabIndex = 3;
            this.lblClienteVenta.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(111, 27);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(52, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "Cliente:";
            // 
            // lblIDVenta
            // 
            this.lblIDVenta.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblIDVenta.Location = new System.Drawing.Point(40, 26);
            this.lblIDVenta.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblIDVenta.Name = "lblIDVenta";
            this.lblIDVenta.Size = new System.Drawing.Size(63, 20);
            this.lblIDVenta.TabIndex = 1;
            this.lblIDVenta.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(8, 27);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(24, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "ID:";
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "FlagJava";
            dataGridViewCellStyle79.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn1.DefaultCellStyle = dataGridViewCellStyle79;
            this.dataGridViewTextBoxColumn1.Frozen = true;
            this.dataGridViewTextBoxColumn1.HeaderText = "FlagJava";
            this.dataGridViewTextBoxColumn1.MaxInputLength = 1;
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn1.Visible = false;
            this.dataGridViewTextBoxColumn1.Width = 65;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "TaraEditada";
            dataGridViewCellStyle80.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn2.DefaultCellStyle = dataGridViewCellStyle80;
            this.dataGridViewTextBoxColumn2.Frozen = true;
            this.dataGridViewTextBoxColumn2.HeaderText = "TaraCalculado";
            this.dataGridViewTextBoxColumn2.MaxInputLength = 11;
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn2.Visible = false;
            this.dataGridViewTextBoxColumn2.Width = 130;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "FlagPesoTara";
            dataGridViewCellStyle81.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn3.DefaultCellStyle = dataGridViewCellStyle81;
            this.dataGridViewTextBoxColumn3.Frozen = true;
            this.dataGridViewTextBoxColumn3.HeaderText = "FlagPesoTara";
            this.dataGridViewTextBoxColumn3.MaxInputLength = 1;
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn3.Visible = false;
            this.dataGridViewTextBoxColumn3.Width = 95;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "CantidadJavas";
            dataGridViewCellStyle82.Format = "N0";
            dataGridViewCellStyle82.NullValue = null;
            this.dataGridViewTextBoxColumn4.DefaultCellStyle = dataGridViewCellStyle82;
            this.dataGridViewTextBoxColumn4.Frozen = true;
            this.dataGridViewTextBoxColumn4.HeaderText = "Cantidad Javas";
            this.dataGridViewTextBoxColumn4.MaxInputLength = 4;
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            this.dataGridViewTextBoxColumn4.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn4.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn4.Visible = false;
            this.dataGridViewTextBoxColumn4.Width = 70;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "PesoJava";
            dataGridViewCellStyle83.Format = "N2";
            dataGridViewCellStyle83.NullValue = null;
            this.dataGridViewTextBoxColumn5.DefaultCellStyle = dataGridViewCellStyle83;
            this.dataGridViewTextBoxColumn5.Frozen = true;
            this.dataGridViewTextBoxColumn5.HeaderText = "Peso Javas";
            this.dataGridViewTextBoxColumn5.MaxInputLength = 11;
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            this.dataGridViewTextBoxColumn5.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn5.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn5.Width = 70;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "PesoBruto";
            dataGridViewCellStyle84.Format = "N2";
            dataGridViewCellStyle84.NullValue = null;
            this.dataGridViewTextBoxColumn6.DefaultCellStyle = dataGridViewCellStyle84;
            this.dataGridViewTextBoxColumn6.Frozen = true;
            this.dataGridViewTextBoxColumn6.HeaderText = "Peso Bruto";
            this.dataGridViewTextBoxColumn6.MaxInputLength = 11;
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            this.dataGridViewTextBoxColumn6.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn6.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn6.Width = 70;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "PesoTara";
            dataGridViewCellStyle85.Format = "N2";
            dataGridViewCellStyle85.NullValue = null;
            this.dataGridViewTextBoxColumn7.DefaultCellStyle = dataGridViewCellStyle85;
            this.dataGridViewTextBoxColumn7.Frozen = true;
            this.dataGridViewTextBoxColumn7.HeaderText = "Peso Tara";
            this.dataGridViewTextBoxColumn7.MaxInputLength = 11;
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            this.dataGridViewTextBoxColumn7.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn7.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn7.Width = 70;
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "PesoNeto";
            dataGridViewCellStyle86.Format = "N2";
            dataGridViewCellStyle86.NullValue = null;
            this.dataGridViewTextBoxColumn8.DefaultCellStyle = dataGridViewCellStyle86;
            this.dataGridViewTextBoxColumn8.Frozen = true;
            this.dataGridViewTextBoxColumn8.HeaderText = "Peso Neto";
            this.dataGridViewTextBoxColumn8.MaxInputLength = 11;
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            this.dataGridViewTextBoxColumn8.ReadOnly = true;
            this.dataGridViewTextBoxColumn8.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn8.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn8.Width = 70;
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "Observacion";
            dataGridViewCellStyle87.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn9.DefaultCellStyle = dataGridViewCellStyle87;
            this.dataGridViewTextBoxColumn9.Frozen = true;
            this.dataGridViewTextBoxColumn9.HeaderText = "Observación";
            this.dataGridViewTextBoxColumn9.MaxInputLength = 200;
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            this.dataGridViewTextBoxColumn9.ReadOnly = true;
            this.dataGridViewTextBoxColumn9.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn9.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn9.Width = 300;
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.DataPropertyName = "IdLineaVenta";
            dataGridViewCellStyle88.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn10.DefaultCellStyle = dataGridViewCellStyle88;
            this.dataGridViewTextBoxColumn10.Frozen = true;
            this.dataGridViewTextBoxColumn10.HeaderText = "IdLineaVenta";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            this.dataGridViewTextBoxColumn10.ReadOnly = true;
            this.dataGridViewTextBoxColumn10.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn10.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn10.Visible = false;
            this.dataGridViewTextBoxColumn10.Width = 220;
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.DataPropertyName = "Indicador";
            this.dataGridViewTextBoxColumn11.Frozen = true;
            this.dataGridViewTextBoxColumn11.HeaderText = "Indicador";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            this.dataGridViewTextBoxColumn11.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn11.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn11.Visible = false;
            this.dataGridViewTextBoxColumn11.Width = 50;
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.DataPropertyName = "IdVenta";
            this.dataGridViewTextBoxColumn12.Frozen = true;
            this.dataGridViewTextBoxColumn12.HeaderText = "IdVenta";
            this.dataGridViewTextBoxColumn12.MaxInputLength = 11;
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            this.dataGridViewTextBoxColumn12.ReadOnly = true;
            this.dataGridViewTextBoxColumn12.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn12.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn12.Visible = false;
            this.dataGridViewTextBoxColumn12.Width = 70;
            // 
            // dataGridViewTextBoxColumn13
            // 
            this.dataGridViewTextBoxColumn13.DataPropertyName = "IdProducto";
            this.dataGridViewTextBoxColumn13.Frozen = true;
            this.dataGridViewTextBoxColumn13.HeaderText = "IdProducto";
            this.dataGridViewTextBoxColumn13.MaxInputLength = 1;
            this.dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
            this.dataGridViewTextBoxColumn13.ReadOnly = true;
            this.dataGridViewTextBoxColumn13.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn13.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn13.Visible = false;
            this.dataGridViewTextBoxColumn13.Width = 70;
            // 
            // dataGridViewTextBoxColumn14
            // 
            this.dataGridViewTextBoxColumn14.DataPropertyName = "TipoDocumento";
            dataGridViewCellStyle89.NullValue = null;
            this.dataGridViewTextBoxColumn14.DefaultCellStyle = dataGridViewCellStyle89;
            this.dataGridViewTextBoxColumn14.Frozen = true;
            this.dataGridViewTextBoxColumn14.HeaderText = "Tipo Documento";
            this.dataGridViewTextBoxColumn14.MaxInputLength = 4;
            this.dataGridViewTextBoxColumn14.Name = "dataGridViewTextBoxColumn14";
            this.dataGridViewTextBoxColumn14.ReadOnly = true;
            this.dataGridViewTextBoxColumn14.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn14.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn14.Visible = false;
            this.dataGridViewTextBoxColumn14.Width = 70;
            // 
            // dataGridViewTextBoxColumn15
            // 
            this.dataGridViewTextBoxColumn15.DataPropertyName = "Producto";
            dataGridViewCellStyle90.Format = "N2";
            dataGridViewCellStyle90.NullValue = null;
            this.dataGridViewTextBoxColumn15.DefaultCellStyle = dataGridViewCellStyle90;
            this.dataGridViewTextBoxColumn15.Frozen = true;
            this.dataGridViewTextBoxColumn15.HeaderText = "Producto";
            this.dataGridViewTextBoxColumn15.MaxInputLength = 11;
            this.dataGridViewTextBoxColumn15.Name = "dataGridViewTextBoxColumn15";
            this.dataGridViewTextBoxColumn15.ReadOnly = true;
            this.dataGridViewTextBoxColumn15.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn15.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn15.Visible = false;
            this.dataGridViewTextBoxColumn15.Width = 200;
            // 
            // dataGridViewTextBoxColumn16
            // 
            this.dataGridViewTextBoxColumn16.DataPropertyName = "Fecha";
            dataGridViewCellStyle91.Format = "d";
            dataGridViewCellStyle91.NullValue = null;
            this.dataGridViewTextBoxColumn16.DefaultCellStyle = dataGridViewCellStyle91;
            this.dataGridViewTextBoxColumn16.HeaderText = "Fecha";
            this.dataGridViewTextBoxColumn16.MaxInputLength = 11;
            this.dataGridViewTextBoxColumn16.Name = "dataGridViewTextBoxColumn16";
            this.dataGridViewTextBoxColumn16.ReadOnly = true;
            this.dataGridViewTextBoxColumn16.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn16.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn16.Width = 80;
            // 
            // dataGridViewTextBoxColumn17
            // 
            this.dataGridViewTextBoxColumn17.DataPropertyName = "strCantidadJavas";
            dataGridViewCellStyle92.NullValue = null;
            this.dataGridViewTextBoxColumn17.DefaultCellStyle = dataGridViewCellStyle92;
            this.dataGridViewTextBoxColumn17.HeaderText = "Cantidad Javas";
            this.dataGridViewTextBoxColumn17.MaxInputLength = 11;
            this.dataGridViewTextBoxColumn17.Name = "dataGridViewTextBoxColumn17";
            this.dataGridViewTextBoxColumn17.ReadOnly = true;
            this.dataGridViewTextBoxColumn17.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn17.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn17.Width = 80;
            // 
            // dataGridViewTextBoxColumn18
            // 
            this.dataGridViewTextBoxColumn18.DataPropertyName = "strPesoNeto";
            dataGridViewCellStyle93.NullValue = null;
            this.dataGridViewTextBoxColumn18.DefaultCellStyle = dataGridViewCellStyle93;
            this.dataGridViewTextBoxColumn18.HeaderText = "Peso Neto";
            this.dataGridViewTextBoxColumn18.MaxInputLength = 11;
            this.dataGridViewTextBoxColumn18.Name = "dataGridViewTextBoxColumn18";
            this.dataGridViewTextBoxColumn18.ReadOnly = true;
            this.dataGridViewTextBoxColumn18.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn18.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn18.Width = 80;
            // 
            // dataGridViewTextBoxColumn19
            // 
            this.dataGridViewTextBoxColumn19.DataPropertyName = "Importe";
            dataGridViewCellStyle94.Format = "N2";
            dataGridViewCellStyle94.NullValue = null;
            this.dataGridViewTextBoxColumn19.DefaultCellStyle = dataGridViewCellStyle94;
            this.dataGridViewTextBoxColumn19.HeaderText = "Importe";
            this.dataGridViewTextBoxColumn19.MaxInputLength = 200;
            this.dataGridViewTextBoxColumn19.Name = "dataGridViewTextBoxColumn19";
            this.dataGridViewTextBoxColumn19.ReadOnly = true;
            this.dataGridViewTextBoxColumn19.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn19.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn19.Width = 90;
            // 
            // dataGridViewTextBoxColumn20
            // 
            this.dataGridViewTextBoxColumn20.DataPropertyName = "strSaldo";
            this.dataGridViewTextBoxColumn20.HeaderText = "Saldo";
            this.dataGridViewTextBoxColumn20.MaxInputLength = 200;
            this.dataGridViewTextBoxColumn20.Name = "dataGridViewTextBoxColumn20";
            this.dataGridViewTextBoxColumn20.ReadOnly = true;
            this.dataGridViewTextBoxColumn20.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn20.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn20.Visible = false;
            this.dataGridViewTextBoxColumn20.Width = 90;
            // 
            // dataGridViewTextBoxColumn21
            // 
            this.dataGridViewTextBoxColumn21.DataPropertyName = "TipoDocumento";
            this.dataGridViewTextBoxColumn21.Frozen = true;
            this.dataGridViewTextBoxColumn21.HeaderText = "Pago a Cuenta";
            this.dataGridViewTextBoxColumn21.MaxInputLength = 1;
            this.dataGridViewTextBoxColumn21.Name = "dataGridViewTextBoxColumn21";
            this.dataGridViewTextBoxColumn21.ReadOnly = true;
            this.dataGridViewTextBoxColumn21.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn21.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn21.Visible = false;
            this.dataGridViewTextBoxColumn21.Width = 90;
            // 
            // dataGridViewTextBoxColumn22
            // 
            this.dataGridViewTextBoxColumn22.DataPropertyName = "Indicador";
            this.dataGridViewTextBoxColumn22.Frozen = true;
            this.dataGridViewTextBoxColumn22.HeaderText = "FlagJava";
            this.dataGridViewTextBoxColumn22.Name = "dataGridViewTextBoxColumn22";
            this.dataGridViewTextBoxColumn22.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn22.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn22.Visible = false;
            this.dataGridViewTextBoxColumn22.Width = 65;
            // 
            // dataGridViewTextBoxColumn23
            // 
            this.dataGridViewTextBoxColumn23.DataPropertyName = "IdVenta";
            this.dataGridViewTextBoxColumn23.Frozen = true;
            this.dataGridViewTextBoxColumn23.HeaderText = "TaraCalculado";
            this.dataGridViewTextBoxColumn23.MaxInputLength = 11;
            this.dataGridViewTextBoxColumn23.Name = "dataGridViewTextBoxColumn23";
            this.dataGridViewTextBoxColumn23.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn23.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn23.Visible = false;
            this.dataGridViewTextBoxColumn23.Width = 130;
            // 
            // dataGridViewTextBoxColumn24
            // 
            this.dataGridViewTextBoxColumn24.DataPropertyName = "IdProducto";
            this.dataGridViewTextBoxColumn24.Frozen = true;
            this.dataGridViewTextBoxColumn24.HeaderText = "FlagPesoTara";
            this.dataGridViewTextBoxColumn24.Name = "dataGridViewTextBoxColumn24";
            this.dataGridViewTextBoxColumn24.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn24.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn24.Visible = false;
            this.dataGridViewTextBoxColumn24.Width = 95;
            // 
            // dataGridViewTextBoxColumn25
            // 
            this.dataGridViewTextBoxColumn25.DataPropertyName = "CantidadJavas";
            dataGridViewCellStyle95.Format = "N0";
            dataGridViewCellStyle95.NullValue = null;
            this.dataGridViewTextBoxColumn25.DefaultCellStyle = dataGridViewCellStyle95;
            this.dataGridViewTextBoxColumn25.HeaderText = "Cantidad Javas";
            this.dataGridViewTextBoxColumn25.MaxInputLength = 4;
            this.dataGridViewTextBoxColumn25.Name = "dataGridViewTextBoxColumn25";
            this.dataGridViewTextBoxColumn25.ReadOnly = true;
            this.dataGridViewTextBoxColumn25.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn25.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn25.Visible = false;
            this.dataGridViewTextBoxColumn25.Width = 70;
            // 
            // dataGridViewTextBoxColumn26
            // 
            this.dataGridViewTextBoxColumn26.DataPropertyName = "PesoJava";
            dataGridViewCellStyle96.Format = "N2";
            dataGridViewCellStyle96.NullValue = null;
            this.dataGridViewTextBoxColumn26.DefaultCellStyle = dataGridViewCellStyle96;
            this.dataGridViewTextBoxColumn26.HeaderText = "Peso Javas";
            this.dataGridViewTextBoxColumn26.MaxInputLength = 11;
            this.dataGridViewTextBoxColumn26.Name = "dataGridViewTextBoxColumn26";
            this.dataGridViewTextBoxColumn26.ReadOnly = true;
            this.dataGridViewTextBoxColumn26.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn26.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn26.Visible = false;
            this.dataGridViewTextBoxColumn26.Width = 70;
            // 
            // dataGridViewTextBoxColumn27
            // 
            this.dataGridViewTextBoxColumn27.DataPropertyName = "strCantidadJavas";
            dataGridViewCellStyle97.Format = "N2";
            dataGridViewCellStyle97.NullValue = null;
            this.dataGridViewTextBoxColumn27.DefaultCellStyle = dataGridViewCellStyle97;
            this.dataGridViewTextBoxColumn27.HeaderText = "Peso Bruto";
            this.dataGridViewTextBoxColumn27.MaxInputLength = 11;
            this.dataGridViewTextBoxColumn27.Name = "dataGridViewTextBoxColumn27";
            this.dataGridViewTextBoxColumn27.ReadOnly = true;
            this.dataGridViewTextBoxColumn27.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn27.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn27.Width = 70;
            // 
            // dataGridViewTextBoxColumn28
            // 
            this.dataGridViewTextBoxColumn28.DataPropertyName = "strPesoNeto";
            dataGridViewCellStyle98.Format = "N2";
            dataGridViewCellStyle98.NullValue = null;
            this.dataGridViewTextBoxColumn28.DefaultCellStyle = dataGridViewCellStyle98;
            this.dataGridViewTextBoxColumn28.HeaderText = "Peso Tara";
            this.dataGridViewTextBoxColumn28.MaxInputLength = 11;
            this.dataGridViewTextBoxColumn28.Name = "dataGridViewTextBoxColumn28";
            this.dataGridViewTextBoxColumn28.ReadOnly = true;
            this.dataGridViewTextBoxColumn28.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn28.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn28.Width = 70;
            // 
            // dataGridViewTextBoxColumn29
            // 
            this.dataGridViewTextBoxColumn29.DataPropertyName = "Importe";
            dataGridViewCellStyle99.Format = "N2";
            dataGridViewCellStyle99.NullValue = null;
            this.dataGridViewTextBoxColumn29.DefaultCellStyle = dataGridViewCellStyle99;
            this.dataGridViewTextBoxColumn29.HeaderText = "Peso Neto";
            this.dataGridViewTextBoxColumn29.MaxInputLength = 11;
            this.dataGridViewTextBoxColumn29.Name = "dataGridViewTextBoxColumn29";
            this.dataGridViewTextBoxColumn29.ReadOnly = true;
            this.dataGridViewTextBoxColumn29.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn29.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn29.Width = 70;
            // 
            // dataGridViewTextBoxColumn30
            // 
            this.dataGridViewTextBoxColumn30.DataPropertyName = "Observacion";
            dataGridViewCellStyle100.Format = "N2";
            dataGridViewCellStyle100.NullValue = null;
            this.dataGridViewTextBoxColumn30.DefaultCellStyle = dataGridViewCellStyle100;
            this.dataGridViewTextBoxColumn30.HeaderText = "Observación";
            this.dataGridViewTextBoxColumn30.MaxInputLength = 200;
            this.dataGridViewTextBoxColumn30.Name = "dataGridViewTextBoxColumn30";
            this.dataGridViewTextBoxColumn30.ReadOnly = true;
            this.dataGridViewTextBoxColumn30.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn30.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn30.Width = 240;
            // 
            // dataGridViewTextBoxColumn31
            // 
            this.dataGridViewTextBoxColumn31.DataPropertyName = "PesoNeto";
            dataGridViewCellStyle101.Format = "N2";
            dataGridViewCellStyle101.NullValue = null;
            this.dataGridViewTextBoxColumn31.DefaultCellStyle = dataGridViewCellStyle101;
            this.dataGridViewTextBoxColumn31.HeaderText = "Pago a Cuenta";
            this.dataGridViewTextBoxColumn31.MaxInputLength = 11;
            this.dataGridViewTextBoxColumn31.Name = "dataGridViewTextBoxColumn31";
            this.dataGridViewTextBoxColumn31.ReadOnly = true;
            this.dataGridViewTextBoxColumn31.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn31.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn31.Width = 90;
            // 
            // dataGridViewTextBoxColumn32
            // 
            this.dataGridViewTextBoxColumn32.DataPropertyName = "Indicador";
            this.dataGridViewTextBoxColumn32.Frozen = true;
            this.dataGridViewTextBoxColumn32.HeaderText = "FlagJava";
            this.dataGridViewTextBoxColumn32.MaxInputLength = 200;
            this.dataGridViewTextBoxColumn32.Name = "dataGridViewTextBoxColumn32";
            this.dataGridViewTextBoxColumn32.ReadOnly = true;
            this.dataGridViewTextBoxColumn32.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn32.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn32.Visible = false;
            this.dataGridViewTextBoxColumn32.Width = 65;
            // 
            // dataGridViewTextBoxColumn33
            // 
            this.dataGridViewTextBoxColumn33.DataPropertyName = "IdVenta";
            this.dataGridViewTextBoxColumn33.Frozen = true;
            this.dataGridViewTextBoxColumn33.HeaderText = "TaraCalculado";
            this.dataGridViewTextBoxColumn33.MaxInputLength = 11;
            this.dataGridViewTextBoxColumn33.Name = "dataGridViewTextBoxColumn33";
            this.dataGridViewTextBoxColumn33.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn33.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn33.Visible = false;
            this.dataGridViewTextBoxColumn33.Width = 130;
            // 
            // dataGridViewTextBoxColumn34
            // 
            this.dataGridViewTextBoxColumn34.DataPropertyName = "IdProducto";
            this.dataGridViewTextBoxColumn34.Frozen = true;
            this.dataGridViewTextBoxColumn34.HeaderText = "FlagPesoTara";
            this.dataGridViewTextBoxColumn34.Name = "dataGridViewTextBoxColumn34";
            this.dataGridViewTextBoxColumn34.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn34.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn34.Visible = false;
            this.dataGridViewTextBoxColumn34.Width = 95;
            // 
            // dataGridViewTextBoxColumn35
            // 
            this.dataGridViewTextBoxColumn35.DataPropertyName = "CantidadJavas";
            dataGridViewCellStyle102.Format = "N0";
            dataGridViewCellStyle102.NullValue = null;
            this.dataGridViewTextBoxColumn35.DefaultCellStyle = dataGridViewCellStyle102;
            this.dataGridViewTextBoxColumn35.HeaderText = "Cantidad Javas";
            this.dataGridViewTextBoxColumn35.MaxInputLength = 4;
            this.dataGridViewTextBoxColumn35.Name = "dataGridViewTextBoxColumn35";
            this.dataGridViewTextBoxColumn35.ReadOnly = true;
            this.dataGridViewTextBoxColumn35.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn35.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn35.Width = 70;
            // 
            // dataGridViewTextBoxColumn36
            // 
            this.dataGridViewTextBoxColumn36.DataPropertyName = "PesoJava";
            dataGridViewCellStyle103.Format = "N2";
            dataGridViewCellStyle103.NullValue = null;
            this.dataGridViewTextBoxColumn36.DefaultCellStyle = dataGridViewCellStyle103;
            this.dataGridViewTextBoxColumn36.HeaderText = "Peso Javas";
            this.dataGridViewTextBoxColumn36.MaxInputLength = 11;
            this.dataGridViewTextBoxColumn36.Name = "dataGridViewTextBoxColumn36";
            this.dataGridViewTextBoxColumn36.ReadOnly = true;
            this.dataGridViewTextBoxColumn36.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn36.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn36.Width = 70;
            // 
            // dataGridViewTextBoxColumn37
            // 
            this.dataGridViewTextBoxColumn37.DataPropertyName = "strCantidadJavas";
            dataGridViewCellStyle104.Format = "N2";
            dataGridViewCellStyle104.NullValue = null;
            this.dataGridViewTextBoxColumn37.DefaultCellStyle = dataGridViewCellStyle104;
            this.dataGridViewTextBoxColumn37.HeaderText = "Peso Bruto";
            this.dataGridViewTextBoxColumn37.MaxInputLength = 11;
            this.dataGridViewTextBoxColumn37.Name = "dataGridViewTextBoxColumn37";
            this.dataGridViewTextBoxColumn37.ReadOnly = true;
            this.dataGridViewTextBoxColumn37.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn37.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn37.Width = 70;
            // 
            // dataGridViewTextBoxColumn38
            // 
            this.dataGridViewTextBoxColumn38.DataPropertyName = "strPesoNeto";
            dataGridViewCellStyle105.Format = "N2";
            dataGridViewCellStyle105.NullValue = null;
            this.dataGridViewTextBoxColumn38.DefaultCellStyle = dataGridViewCellStyle105;
            this.dataGridViewTextBoxColumn38.HeaderText = "Peso Tara";
            this.dataGridViewTextBoxColumn38.MaxInputLength = 11;
            this.dataGridViewTextBoxColumn38.Name = "dataGridViewTextBoxColumn38";
            this.dataGridViewTextBoxColumn38.ReadOnly = true;
            this.dataGridViewTextBoxColumn38.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn38.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn38.Width = 70;
            // 
            // dataGridViewTextBoxColumn39
            // 
            this.dataGridViewTextBoxColumn39.DataPropertyName = "Importe";
            dataGridViewCellStyle106.Format = "N2";
            dataGridViewCellStyle106.NullValue = null;
            this.dataGridViewTextBoxColumn39.DefaultCellStyle = dataGridViewCellStyle106;
            this.dataGridViewTextBoxColumn39.HeaderText = "Peso Neto";
            this.dataGridViewTextBoxColumn39.MaxInputLength = 11;
            this.dataGridViewTextBoxColumn39.Name = "dataGridViewTextBoxColumn39";
            this.dataGridViewTextBoxColumn39.ReadOnly = true;
            this.dataGridViewTextBoxColumn39.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn39.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn39.Width = 70;
            // 
            // dataGridViewTextBoxColumn40
            // 
            this.dataGridViewTextBoxColumn40.DataPropertyName = "Observacion";
            this.dataGridViewTextBoxColumn40.HeaderText = "Observación";
            this.dataGridViewTextBoxColumn40.MaxInputLength = 200;
            this.dataGridViewTextBoxColumn40.Name = "dataGridViewTextBoxColumn40";
            this.dataGridViewTextBoxColumn40.ReadOnly = true;
            this.dataGridViewTextBoxColumn40.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn40.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn40.Width = 240;
            // 
            // frmDetalleVenta
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(922, 544);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.tcVenta);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmDetalleVenta";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "DGP - Detalle Venta";
            this.Load += new System.EventHandler(this.frmDetalleVenta_Load);
            this.tcVenta.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgrvLineaVentaDS)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudPrecioAmortizacion)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgrvAmortizacion)).EndInit();
            this.tabPage3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgrvDevolucion)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudPrecioVenta)).EndInit();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tcVenta;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label lblIDVenta;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lblClienteVenta;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblProductoVenta;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblSimboloMoneda;
        private System.Windows.Forms.Label lblEmpresaVenta;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.Button btnRestablecerLineaVenta;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.Button btnAceptarLineaVenta;
        private System.Windows.Forms.DataGridView dgrvAmortizacion;
        private System.Windows.Forms.Label lblSimboloMonedaAM;
        private System.Windows.Forms.NumericUpDown nudPrecioAmortizacion;
        private System.Windows.Forms.Button btnAplicarMonto;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btnAceptarAmortizacionVenta;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn14;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn15;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn16;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn17;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn18;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn19;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn20;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn21;
        private System.Windows.Forms.Button btnAceptarDevolucionVenta;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lblTotalNetoD;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lblTotalTaraD;
        private System.Windows.Forms.Label lblTotalBrutoD;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn22;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn23;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn24;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn25;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn26;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn27;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn28;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn29;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn30;
        private System.Windows.Forms.DataGridViewButtonColumn dataGridViewButtonColumn1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txtObservaciones;
        private System.Windows.Forms.Button btnCancelarVenta;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.DataGridView dgrvLineaVentaDS;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn31;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn32;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn33;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn34;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn35;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn36;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn37;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn38;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn39;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn40;
        private System.Windows.Forms.DataGridViewTextBoxColumn dcaColumn00;
        private System.Windows.Forms.DataGridViewTextBoxColumn dcaColumn01;
        private System.Windows.Forms.DataGridViewTextBoxColumn dcaColumn02;
        private System.Windows.Forms.DataGridViewTextBoxColumn dcaColumn03;
        private System.Windows.Forms.DataGridViewTextBoxColumn dcaColumn04;
        private System.Windows.Forms.DataGridViewTextBoxColumn dcaColumn05;
        private System.Windows.Forms.DataGridViewTextBoxColumn dcaColumn06;
        private System.Windows.Forms.DataGridViewTextBoxColumn dcaColumn07;
        private System.Windows.Forms.DataGridViewTextBoxColumn dcaColumn08;
        private System.Windows.Forms.DataGridViewTextBoxColumn dcaColumn09;
        private System.Windows.Forms.DataGridViewTextBoxColumn dcaColumn10;
        private System.Windows.Forms.ComboBox cbEstadoVentaG;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridView dgrvDevolucion;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label lblCabTotalNeto;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label lblCabTotalTara;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label lblCabTotalBruto;
        private System.Windows.Forms.NumericUpDown nudPrecioVenta;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label lblImporte;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label lblDevoluciones;
        private System.Windows.Forms.Label lblUnidades;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.DataGridViewTextBoxColumn dsColumn01;
        private System.Windows.Forms.DataGridViewTextBoxColumn dsColumn02;
        private System.Windows.Forms.DataGridViewTextBoxColumn dsColumn03;
        private System.Windows.Forms.DataGridViewTextBoxColumn dsColumn04;
        private System.Windows.Forms.DataGridViewTextBoxColumn dsColumn05;
        private System.Windows.Forms.DataGridViewTextBoxColumn dsColumn06;
        private System.Windows.Forms.DataGridViewTextBoxColumn dsColumn07;
        private System.Windows.Forms.DataGridViewTextBoxColumn dsColumn08;
        private System.Windows.Forms.DataGridViewTextBoxColumn dsColumn09;
        private System.Windows.Forms.DataGridViewTextBoxColumn dsColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn Unidades;
        private System.Windows.Forms.DataGridViewButtonColumn dsColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dcdColumn00;
        private System.Windows.Forms.DataGridViewTextBoxColumn dcdColumn01;
        private System.Windows.Forms.DataGridViewTextBoxColumn dcdColumn02;
        private System.Windows.Forms.DataGridViewTextBoxColumn dcdColumn03;
        private System.Windows.Forms.DataGridViewTextBoxColumn dcdColumn04;
        private System.Windows.Forms.DataGridViewTextBoxColumn dcdColumn05;
        private System.Windows.Forms.DataGridViewTextBoxColumn dcdColumn06;
        private System.Windows.Forms.DataGridViewTextBoxColumn dcdColumn07;
        private System.Windows.Forms.DataGridViewTextBoxColumn dcdColumn08;
        private System.Windows.Forms.DataGridViewTextBoxColumn dcdColumn09;
        private System.Windows.Forms.DataGridViewTextBoxColumn UnidadesDesc;
        private System.Windows.Forms.DataGridViewButtonColumn dcdColumn10;
    }
}